extends VBoxContainer

var CONTENEDOR_COMPONENTE = load("res://Escenas/componente_base.tscn")
var FILA_PROPIEDAD = load("res://Escenas/valores_del_editor.tscn")
var ico = load("res://sprites/atclas textura2.png")

var style_color:= StyleBoxFlat.new()
var style_textura:= StyleBoxFlat.new()

var pool_headers: Array[Node] = []
var headers_activos: int = 0

var propiedad_actual = null
var componente_actual = null
var entidad_actual = null
var ectivar:bool = false

var con
var nom_var:String
var panel_boton = null

signal actualizar_propiedades(clase:String )
signal abrir_editor_recuadro

func _on_teclado_oculto() -> void:
	if componente_actual == null:
		return
	emit_signal("actualizar_propiedades",componente_actual)

func _ready() -> void:
	if Variables.tipo_entrada !=2:
		return
	
	for i in range(8):
		var header = CONTENEDOR_COMPONENTE.instantiate()
		add_child(header)
		header.hide()
		
		var lista_props = header.get_node("lista valores")
		for j in range(8):
			var fila = FILA_PROPIEDAD.instantiate()
			lista_props.add_child(fila)
			fila.hide()
		pool_headers.append(header)
	actualizar_inspector([Transform.new()])
	pool_headers[0].hide()
	headers_activos = 0
	style_textura = pool_headers[0].get_node("lista valores/Valores del editor/ContenedorTextura/boton").get_theme_stylebox("panel")
	style_color.bg_color = Color.WHITE
	style_color.border_color = Color(0.0, 0.0, 0.0, 1.0)
	style_color.border_width_left = 3
	style_color.border_width_top = 3
	style_color.border_width_right = 3
	style_color.border_width_bottom = 3
	
	style_color.corner_radius_top_left = 8
	style_color.corner_radius_top_right = 8
	style_color.corner_radius_bottom_right = 8
	style_color.corner_radius_bottom_left = 8
	
	Teclado.teclado_ocultodo.connect(_on_teclado_oculto)

func actualizar_inspector(entidad) -> void:
	if entidad == null: return
	entidad_actual = entidad
	headers_activos = 0
	# Ocultamos todos los headers del pool instantáneamente (Operación O(1) ultra rápida)
	for h in pool_headers:
		h.hide()
	for comp_id in entidad.size():
		var componente = entidad[comp_id]
		_dibujar_componente_estilo_unity(componente)

func _dibujar_componente_estilo_unity(componente) -> void:
	if headers_activos >= pool_headers.size():#cuando ya no más componentes
		var nuevo_header = CONTENEDOR_COMPONENTE.instantiate()
		add_child(nuevo_header)
		var node = nuevo_header.get_node("lista valores")
		for j in range(9):
			var fila = FILA_PROPIEDAD.instantiate()
			node.add_child(fila)
			fila.hide()
		pool_headers.append(nuevo_header)
	
	var header = pool_headers[headers_activos]
	headers_activos += 1
	header.show()
	header.get_node("vara com/nombre").text = componente.nombre_componentes
	if "ICONO" in componente :
		header.get_node("vara com/icon").icon = textura_region(componente.ICONO)
		header.get_node("vara com/icon").modulate = Color(0.0, 0.567, 1.0, 1.0)
	var lista_props = header.get_node("lista valores")
	var boton_colapsar = header.get_node("vara com/v")
	
	# Manejar el ocultar/desplegar estilo Unity
	lista_props.visible = not componente.colapsado
	boton_colapsar.text = "v" if lista_props.visible else ">"
	
	if not boton_colapsar.pressed.is_connected(_on_colapsar_presionado) and ectivar:
		boton_colapsar.pressed.connect(_on_colapsar_presionado.bind(componente))
	
	var filas_del_header = lista_props.get_children()
	for f in filas_del_header:
		f.hide()
	
	var filas_usadas = 0
	for prop in componente.get_property_list():
		if prop.usage & PROPERTY_USAGE_SCRIPT_VARIABLE:
			if prop["name"] =="region":
				return
			
			# Si el componente tiene más de 15 variables, expandimos sus filas internas
			if filas_usadas >= filas_del_header.size():
				var nueva_fila = FILA_PROPIEDAD.instantiate()
				lista_props.add_child(nueva_fila)
				filas_del_header.append(nueva_fila)
				
			var fila = filas_del_header[filas_usadas]
			filas_usadas += 1
			# Inicializamos y limpiamos los inputs de la fila antes de usarla
			_ocultar_todos_los_inputs(fila)
			
			if not componente.colapsado and prop.name != "nombre_componentes"and prop.name!="colapsado":
				fila.show()
			if ectivar:
				_configurar_inputs_fila(fila, componente, prop)
			ectivar = true

func _ocultar_todos_los_inputs(fila) -> void:
	fila.get_node("punto/CheckBox").hide()
	fila.get_node("punto/LineEdit").hide()
	fila.get_node("OptionButton").hide()
	fila.get_node("ContenedorTextura").hide()

func _configurar_inputs_fila(fila, componente, prop) -> void:
	var nombre_var = prop.name
	var tipo_var = prop.type
	var valor_actual = componente.get(nombre_var)
	fila.get_node("Label").text = "  "+nombre_var.capitalize()
	fila.get_node("ContenedorTextura/TexturePreview/edit").hide()
	
	if prop.hint == PROPERTY_HINT_ENUM:
		var opt_button: OptionButton = fila.get_node("OptionButton")
		opt_button.clear()
		var opciones = prop.hint_string.split(",")
		for opcion in opciones:
			opt_button.add_item(opcion)
			
		opt_button.selected = valor_actual
		opt_button.show()
		
		_reconectar_senal(opt_button.item_selected, _on_enum_cambiado.bind(componente, nombre_var))
		return
	# VARIABLE TIPO TEXTURA  
	if tipo_var == TYPE_STRING and "textura" in nombre_var.to_lower():
		var contenedor_tex = fila.get_node("ContenedorTextura")
		var tex_rect: TextureRect = contenedor_tex.get_node("TexturePreview")
		var label_estado: Label = contenedor_tex.get_node("LabelEstado")
		contenedor_tex.get_node("LabelEstado").show()
		contenedor_tex.get_node("boton").add_theme_stylebox_override("panel",style_textura)
		
		# Caso 1: La propiedad está VACÍA ("")
		if valor_actual == "":
			label_estado.text = "bacia"
			label_estado.show()
			
		# Caso 2: La propiedad TIENE UNA TEXTURA VÁLIDA
		elif ResourceLoader.exists(valor_actual):
			tex_rect.get_node("edit").show()
			var textura_real = load(valor_actual)
			var re:Vector2 = componente.region.size
			var po:Vector2 = componente.region.position +re/2
			tex_rect.texture = textura_real
			label_estado.hide()
			tex_rect.material.set_shader_parameter("recuadro_tamano",re)
			tex_rect.material.set_shader_parameter("recuadro_centro",po)
			_reconectar_senal(tex_rect.get_node("edit").gui_input,editar_region_textura.bind(tex_rect))
			# Caso 3: La ruta tiene texto pero el archivo no existe (Error)
		else:
			#tex_rect.texture = load("res://sprites/delete.png") # Un icono de alerta o cruz
			label_estado.text = "No encontrada"
			label_estado.show()
			
		contenedor_tex.show()
		# Conectamos el clic al cuadro de textura para abrir el explorador de archivos de tu motor
		_reconectar_senal(tex_rect.gui_input, _on_textura_cliqueada.bind(componente, nombre_var, tex_rect, label_estado))
		return
	
	if tipo_var == TYPE_INT or tipo_var == TYPE_FLOAT:
		var sb = fila.get_node("punto/LineEdit")
		sb.text = str(valor_actual)
		sb.show()
		_reconectar_senal(sb.text_changed, _on_valor_cambiado.bind(componente, nombre_var))
	if tipo_var == TYPE_COLOR:
		var sb: Panel = fila.get_node("ContenedorTextura/boton")
		var bo:TextureRect = fila.get_node("ContenedorTextura/TexturePreview")
		fila.get_node("ContenedorTextura/LabelEstado").hide()
		fila.get_node("ContenedorTextura").show()
		sb.add_theme_stylebox_override("panel",style_color)
		
		# Cambiamos el color visualmente sin disparar alertas intermedias
		sb.set_block_signals(true)
		sb.modulate = valor_actual
		sb.set_block_signals(false)
		sb.show()
		
		_reconectar_senal(bo.gui_input, _on_color_confirmado.bind(componente, nombre_var, sb))
		return
	elif tipo_var == TYPE_BOOL:
		var cb = fila.get_node("punto/CheckBox")
		cb.button_pressed = valor_actual
		cb.show()
		_reconectar_senal(cb.toggled, _on_valor_cambiado.bind(componente, nombre_var))

func _on_color_confirmado(_ven,componente, nombre_var, boton_color: Panel) -> void:
	componente.set(nombre_var, boton_color.modulate)
	panel_boton = boton_color
	con = componente
	nom_var = nombre_var
	Input.action_press("mostrar_bara_color")
	Input.action_release("mostrar_bara_color")

func _limpiar_conexiones_de_senal(senal: Signal) -> void:
	for conexion in senal.get_connections():
		senal.disconnect(conexion.callable)

# --- GESTIÓN DE EVENTOS DE LA UI ---
func _on_colapsar_presionado(componente) -> void:
	componente.colapsado = not componente.colapsado
	actualizar_inspector(entidad_actual)

func _on_valor_cambiado(nuevo_valor, componente, nombre_var) -> void:
	componente.set(nombre_var, nuevo_valor)
	componente_actual = componente.nombre_componentes
	emit_signal("actualizar_propiedades",componente.nombre_componentes)

func _on_enum_cambiado(index: int, componente, nombre_var) -> void:
	componente.set(nombre_var, index)
	emit_signal("actualizar_propiedades",componente.nombre_componentes)

func textura_region(numero: int) -> AtlasTexture:
	var columnas:=8
	var tamano_celda= Vector2(30,30)
	var columna = numero+8 % columnas
	var fila := floori(float(numero+8) / columnas)
	var nueva_textura := AtlasTexture.new()
	nueva_textura.atlas = ico # Textura base del Atlas
	
	nueva_textura.region = Rect2(Vector2(columna, fila) * tamano_celda, tamano_celda)
	return nueva_textura

func _on_textura_cliqueada(event: InputEvent, componente, nombre_var, tex_rect, label_estado) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		var ruta_seleccionada = "res://icon.svg"
		componente.set(nombre_var, ruta_seleccionada)
		tex_rect.texture = load(ruta_seleccionada)
		label_estado.hide() # Ocultamos el cartel de "vacía"
		if componente.nombre_componentes =="Sprite":
			var re:Vector2= componente.region.size
			var po:Vector2= componente.region.position +re/2
			tex_rect.material.set_shader_parameter("recuadro_tamano",re)
			tex_rect.material.set_shader_parameter("recuadro_centro",po)
			
		actualizar_inspector(entidad_actual)
		Input.action_press("asigna una textura")
		Input.action_release("asigna una textura")

func _reconectar_senal(senal: Signal, metodo: Callable) -> void:
	for conexiones in senal.get_connections():
		senal.disconnect(conexiones.callable)
	senal.connect(metodo)

func _on_fondo_final_bara() -> void:
	con = null
	nom_var = ""
	panel_boton = null

func editar_region_textura(event,rec:TextureRect):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		abrir_editor_recuadro.emit()
		propiedad_actual = rec

func _on_fondo_color_elegido_movil(color: Color) -> void:
	if nom_var != null and panel_boton != null:
		con.set(nom_var, color)
		panel_boton.modulate = color
		emit_signal("actualizar_propiedades",con.nombre_componentes)

func _on_juego_copia_actualizar_inspector() -> void:
	actualizar_inspector(entidad_actual)
