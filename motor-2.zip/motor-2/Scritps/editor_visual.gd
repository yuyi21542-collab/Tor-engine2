extends Control

var expr = Expression.new()
@export var objeto_pro:Node
var hijo = "chinematico"
var estado = "position"
var Nombre
var valor = "0.0"
var cuerpos = ["chinematico","estatico","rigibody"]

func _ready() -> void:
	$vara/lineal/primero.folded = true
	if false:
		configura()
	for boton in $nu.get_children():
		if boton is Button:
			boton.pressed.connect(_on_button_pressed.bind(boton.name))
	for comando in $vara/lineal/primero/re.get_children():
		comando.pressed.connect(añade_propieda.bind(comando.tooltip_text))
	


func configura():
	if Variables.lis_requisitos.size() > 0:
		hijo = cuerpos[Variables.inicial[str(Variables.ide) +"cuerpos"][0]]
		estado = Variables.lis_requisitos[1]
		Nombre = Variables.lis_requisitos[2]
		if Variables.lis_requisitos[4]=="primero":
			valor = Variables.lis_requisitos[3]
		else:
			valor = Variables.lis_requisitos[4]
	if Variables.lis_requisitos[4]=="primero":
		if Variables.lis_requisitos[1] =="position" or Variables.lis_requisitos[1]=="velocity":
			$tex.text = str(valor.x)
	if Variables.lis_requisitos[4]=="segundo":
		if Variables.lis_requisitos[1] =="position" or Variables.lis_requisitos[1]=="velocity":
			$tex.text = str(valor.y)
	if Variables.lis_requisitos[1] =="rotation" or Variables.lis_requisitos[1]=="si es verdadero":
		$tex.text = str(valor)
	

func _on_button_pressed(nombre):
	if nombre!="punto":
		$tex.text += str(nombre)
	else:
		$tex.text += "."
	var formula = $tex.text
	var objeto_hijo = objeto_pro.get_node(hijo)
	if not objeto_hijo:
		print("Error: No se encontró la entidad")
		return
	
	var nombres_var = []
	var valores_var = []
	
	for prop in objeto_hijo.get_property_list():
		if prop.usage & PROPERTY_USAGE_SCRIPT_VARIABLE:
			nombres_var.append(prop.name)
			valores_var.append(objeto_hijo.get(prop.name))
	
	var error = expr.parse(formula, nombres_var)
	
	if error != OK:
		$muesta_error.visible = true
		$muesta_error.text = "Error: "+ str(expr.get_error_text())
	else:
		$muesta_error.visible = false


func añade_propieda(nodo:String):
	$tex.text += nodo
	pass

func _on_eliminar_pressed() -> void:
	$tex.text = $tex.text.left(-1) + ""
	


func _on_salir_pressed() -> void:
	if Variables.lis_requisitos[4] =="primero":
		if Variables.lis_requisitos[1] =="position" or Variables.lis_requisitos[1] =="velocity":
			Variables.lis_requisitos[3] = Vector2(int($tex.text),0)
		elif Variables.lis_requisitos[1] =="rotation":
			Variables.lis_requisitos[3] = int($tex.text)
		elif Variables.lis_requisitos[1] != "velocity":
			Variables.lis_requisitos[3] = $tex.text
	
	get_tree().call_deferred("change_scene_to_file", "res://ventana.tscn")
	
	
