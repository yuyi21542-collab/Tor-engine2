extends CanvasLayer

@export var crea_nodo:Node2D
@export var canvia_texto:Control
@export var lista_de_categorias: = []
@onready var col = $bae/scrol/VS
@onready var even = $bae/scrol/VS/eventos
@onready var prop = $bae/scrol/VS/propiedades
@onready var sies = $bae/scrol/VS/condicion
var feliz:String
var usar_transform:bool = false
var se_puede = true
var se_jenera_los_com: = false
var arrastrando:bool = false
var arrastrando2:bool = false
var conten = 0
var option:Array[String] = []
var lista_de_cotadores = []
var componente_ide:Dictionary

func dime_para_crear_el_nodo(nombre):
	crea_nodo.crear_nodo(nombre)

func _input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if $bae/scrol.get_global_rect().has_point($d.get_global_mouse_position()):
				arrastrando = true
			if $bac/scrol2.get_global_rect().has_point($d.get_global_mouse_position()):
				arrastrando2 = true
		else:
			arrastrando = false
			arrastrando2 = false
	if event is InputEventScreenDrag:
		if arrastrando:
			$bae/scrol.scroll_vertical -= event.relative.y
		if arrastrando2:
			$bac/scrol2.scroll_vertical -= event.relative.y
	if event is InputEventScreenTouch:
		
		if $bae/scrol/VS/eventos/Node2D/Button.button_pressed:
			even.folded = not even.folded
		if $bae/scrol/VS/propiedades/Node2D/Button.button_pressed:
			prop.folded = not prop.folded
		if $bae/scrol/VS/condicion/Node2D/Button.button_pressed:
			sies.folded = not sies.folded
	#if Input.is_action_just_pressed("mostrar_componente")and se_puede:
		
	if event.is_action_pressed("script")and se_puede:
		Variables.tipo_entrada = 2.9
		col.set("theme_override_constants/separation",10)
	if Input.is_action_just_pressed("mas_script"):
		var op:int
		var nom = str(Variables.ide)
		if not Variables.guardar_script.has(nom):
			Variables.guardar_script[nom] = []
			op = 1
		if Variables.guardar_script[nom].size()>0:
			op = Variables.guardar_script[nom].size() + 1
		
		option.append("script"+str(op))
		feliz = "script"+str(op)
		Variables.guardar_script[nom].append(feliz)
		Variables.block_script[nom + feliz] = []
		Variables.nodos_posiciones[nom + feliz] = []
		Variables.scrit_nodos[nom + feliz] = {}
		Variables.block_script_global[nom + feliz] = []
		Variables.script_globales[nom + feliz] = {}
		Variables.conexiones[nom + feliz] =[]
		
	if event.is_action_pressed("abrir_script"):
		Variables.tipo_entrada = 2.9
		$bae/scrol.size.y = 700
		col.set("theme_override_constants/separation",10)
		$bae.self_modulate = Color(0.0, 0.0, 0.0, 0.0)

func conect_categoria_hijos():#conecta los botones ala funsion que crea los nodos
	for i in lista_de_categorias.size():
		var tipo = lista_de_categorias[i]
		var nodo = get_node(tipo)
		for boton in nodo.get_children():
			if boton is Button:
				boton.pressed.connect(dime_para_crear_el_nodo.bind(boton.name))

func crea_el_nombre_del_script(entrada):##carga los script de una entida en el array
	if Variables.guardar_script.has(str(Variables.ide)):
		if entrada =="recargar":
			option.clear()
			for i in Variables.guardar_script[str(Variables.ide)].size():
				var lista = Variables.guardar_script[str(Variables.ide)]
				option.append(lista[i])

func recargar():##recarga la vara de objetos
	crea_el_nombre_del_script("recargar")

func pre_intancia_componentes():
	task_id = WorkerThreadPool.add_task(_preparar_escena_en_segundo_plano)
	
	await get_tree().create_timer(1).timeout
	mostrar_escena_rapido()

const ESCENA_PESADA_PATH = "res://"
var insta_componente: Control = null
var task_id: int = -1

func _preparar_escena_en_segundo_plano() -> void:
	# 1. Carga el archivo del disco de forma segura
	ResourceLoader.load_threaded_request(ESCENA_PESADA_PATH)
	while ResourceLoader.load_threaded_get_status(ESCENA_PESADA_PATH) == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
		OS.delay_msec(3) # Espera un milisegundo si aún no termina
	var packed_scene = ResourceLoader.load_threaded_get(ESCENA_PESADA_PATH)
	if packed_scene:
		insta_componente = packed_scene.instantiate()

func mostrar_escena_rapido() -> void:
	if WorkerThreadPool.is_task_completed(task_id) and insta_componente:
		add_child.call_deferred(insta_componente)
		insta_componente.hide()
	else:
		print("La escena aún se está procesando en segundo plano...")

func _on_contenedor_añadir_componente(_tipo:int ) -> void:
	var com:Array = Variables.inicial[str(Variables.ide)]
	if com.size()>0:
		%conten_datos.actualizar_inspector(com)

func _on_contenedor_actualizar_compotente(ti) -> void:
	if ti ==4:
		crea_nodo.crea_colision()
	var com:Array = Variables.inicial[str(Variables.ide)]
	if com.size()>0:
		%conten_datos.actualizar_inspector(com)
	
	
