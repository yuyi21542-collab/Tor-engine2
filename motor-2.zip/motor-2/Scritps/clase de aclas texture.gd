class_name DynamicAtlas
extends RefCounted

var atlas_texture: ImageTexture
# Guardará: "nombre_textura": Rect2(x, y, w, h) en píxeles
var texture_rects: Dictionary = {} 
# Guardará las coordenadas UV normalizadas (0.0 a 1.0)
var texture_uvs: Dictionary = {}

var _atlas_size: Vector2i

func _init(size: Vector2i = Vector2i(2048, 2048)):
	_atlas_size = size

## Empaqueta un Diccionario de imágenes {"id_o_nombre": Image}
func generate_atlas(images: Dictionary) -> bool:
	texture_rects.clear()
	texture_uvs.clear()
	
	# Lienzo vacío en formato RGBA8
	var atlas_image := Image.create(_atlas_size.x, _atlas_size.y, false, Image.FORMAT_RGBA8)
	atlas_image.fill(Color(0, 0, 0, 0)) # Transparente
	
	# Ordenar las imágenes de mayor a menor altura mejora la eficiencia del empaquetado (Shelf Packing)
	var keys = images.keys()
	keys.sort_custom(func(a, b): return images[a].get_height() > images[b].get_height())
	
	var current_x := 0
	var current_y := 0
	var row_max_h := 0
	var padding := 2 # Margen para evitar sangrado de píxeles (bleeding)
	
	for id in keys:
		var img: Image = images[id]
		
		# Asegurar que la imagen esté en un formato compatible con el atlas
		if img.get_format() != Image.FORMAT_RGBA8:
			img.convert(Image.FORMAT_RGBA8)
		
		var w := img.get_width()
		var h := img.get_height()
		
		# Si no cabe en la fila actual, saltar a la siguiente fila
		if current_x + w + padding > _atlas_size.x:
			current_x = 0
			current_y += row_max_h + padding
			row_max_h = 0
		
		# Verificar si excede el tamaño máximo del atlas
		if current_y + h + padding > _atlas_size.y:
			push_error("El atlas se ha quedado sin espacio para la imagen: %s" % str(id))
			return false
		
		# Copiar los píxeles de la imagen al atlas principal
		var dest_pos := Vector2i(current_x, current_y)
		atlas_image.blit_rect(img, Rect2i(Vector2i.ZERO, img.get_size()), dest_pos)
		
		# Guardar información de rectángulos y UVs
		var rect := Rect2(current_x, current_y, w, h)
		texture_rects[id] = rect
		
		# Convertir coordenadas de píxeles a espacio UV (0.0 a 1.0)
		texture_uvs[id] = Rect2(
			float(current_x) / _atlas_size.x,
			float(current_y) / _atlas_size.y,
			float(w) / _atlas_size.x,
			float(h) / _atlas_size.y
		)
		current_x += w + padding
		row_max_h = max(row_max_h, h)
	
	# Generar la textura final de la GPU
	atlas_texture = ImageTexture.create_from_image(atlas_image)
	return true
