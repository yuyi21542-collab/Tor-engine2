extends Node2D

# --- CONFIGURACIÓN DE RECURSOS ---
@export var ui_texture: Texture2D
@export var lis:Array[Texture2D ]

var proses:bool = false
var filter_entidades:PackedInt32Array 

var builder:= DynamicAtlas.new(Vector2i(2048, 2048))
var ecs = ECS_DATOS.new()
var creitor = ECS_SISTEMAS.new()


func carga_aclas():
	var user_images :Dictionary
	for iten in Variables.sprites.size():
		user_images[iten] = Variables.sprites[iten].get_image()
	builder.generate_atlas(user_images)

func _ready() -> void:
	#carga_aclas()
	ecs.array_de_script.append(jenerar_entidades)
	Variables.sprites = lis
	ecs.ui_layer_rid = RenderingServer.canvas_create()
	RenderingServer.viewport_attach_canvas(get_viewport().get_viewport_rid(), ecs.ui_layer_rid)
	# Le damos una prioridad de dibujo alta (Equivalente al Layer en nodos)
	RenderingServer.viewport_set_canvas_stacking(get_viewport().get_viewport_rid(), ecs.ui_layer_rid, 10, 0)
	creitor.inisial(get_canvas(),get_world_2d().space, builder)
	
	
	for i in range(0):
		create_ui_object(Vector2(randf_range(1, 1900), randf_range(10, 800)), Vector2(0.7, 0.7))

var codigo_usuario = """
sist bucle(dt):
	velocity.x = randi_range(-1,1) *200
"""

var jenerar_entidades = """
sist inicial():
	for i in range(100):
		var componentes:Array
		componentes.append(Transform.new())
		componentes.append(Sprite.new())
		componentes.append(CuerpoFisico.new())
		componentes.append(Colision.new())
		componentes.append(Scritps.new())
		
		componentes[0].pos_x = randi_range(-700,700)
		componentes[0].pos_y = randi_range(-330,330)
		
		componentes[0].scala_x = 0.5
		componentes[0].scala_y = 0.5
		
		Tur.create_entida(componentes)
"""




func _input(_event):
	if Input.is_action_just_pressed("canviar_sprite"):
		await get_tree().create_timer(0.01).timeout
		creitor.canviar_texture(Variables.ide,ecs)

func actualizar_propiedades(clase:String,delta:float,id_script):
	var entidades_grupo: Array = ecs.grupos_arquetipos[id_script]
	var script_instancia = ecs.instancias_scripts[id_script]
	if script_instancia.has_method(clase):
		_ejecutar_lote_script(clase,script_instancia, entidades_grupo, delta)

func _physics_process(delta: float) -> void:
	if not proses:
		return
	actualizar_propiedades("bucle",delta,ecs.array[1])
	creitor.update(ecs,delta)

func _ejecutar_lote_script(clase:String ,script_instancia: Object, indices: Array, delta: float) -> void:
	# Construcción rápida de slices para el grupo de script activo
	var sub_pos = PackedVector2Array()
	var sub_vel = PackedVector2Array()
	var sub_col = PackedColorArray()
	#var sub_vars: Array[Dictionary] = []
	var sub_tex = PackedInt32Array()
	
	sub_pos.resize(indices.size())
	sub_vel.resize(indices.size())
	sub_col.resize(indices.size())
	sub_tex.resize(indices.size())
	
	for i in range(indices.size()):
		var idx = indices[i]
		sub_pos[i] = ecs.positions[idx]
		sub_vel[i] = ecs.velocidades[idx]
		sub_col[i] = ecs.colores[idx]
		#sub_vars.append(variables_custom[idx])
		sub_tex[i] = ecs.texture_indices[idx]
	
	# Ejecución de la lógica interna (con sus ifs/whiles anidados)
	if clase == "bucle":
		script_instancia.call(clase, sub_pos, sub_vel, sub_col, delta, sub_tex)
	elif clase  == "inicial":
		script_instancia.call(clase, sub_pos, sub_vel, sub_col, sub_tex)
	
	# Recomposición de los datos modificados al buffer global
	for i in range(indices.size()):
		var idx = indices[i]
		ecs.positions[idx] = sub_pos[i]
		ecs.velocidades[idx] = sub_vel[i]
		ecs.colores[idx] = sub_col[i]
		ecs.texture_indices[idx] = sub_tex[i]

## NUEVA FUNCIÓN: Crear objetos de tipo Interfaz (Sin Físicas)
func create_ui_object(screen_pos: Vector2, scala: Vector2) -> void:
	if not ui_texture:
		push_warning("Falta asignar la textura de UI en el inspector.")
		return
	
	var ui_visual_rid = RenderingServer.canvas_item_create()
	
	RenderingServer.canvas_item_set_parent(ui_visual_rid, ecs.ui_layer_rid)
	
	var xform = Transform2D(0.0, screen_pos).scaled(scala)
	RenderingServer.canvas_item_set_transform(ui_visual_rid, xform)
	
	# 3. Dibujar la textura de interfaz (Anclada desde la esquina superior izquierda como los Control)
	var tex_size = ui_texture.get_size()
	RenderingServer.canvas_item_add_texture_rect(ui_visual_rid, Rect2(Vector2.ZERO, tex_size), ui_texture.get_rid())
	RenderingServer.canvas_item_set_z_index(ui_visual_rid, 100)
	
	var ui_item = ecs.UIItem.new()
	ui_item.visual_rid = ui_visual_rid
	ui_item.screen_position = screen_pos
	ecs.active_ui_items.append(ui_item)

func _on_juego_2d_array_cargados(id) -> void:
	if id != null:
		actualizar_propiedades("inicial",1.0,id)
	creitor.crear_entidades(ecs)
	#ecs.entidades_activas.append(0)
	
