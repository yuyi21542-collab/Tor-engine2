extends Node

signal añadir_datos(iten,Array)

func create_entida(iten:Array):
	añadir_datos.emit(iten)
