class_name CompiladorComportamientoECS
extends RefCounted

static func compilar_script_entidad(codigo_usuario: String) -> GDScript:
	var lineas: PackedStringArray = codigo_usuario.split("\n")
	var codigo_procesado: String = ""
	
	var en_bloque_sist: bool = false
	var indentacion_base_bloque: int =0
	
	var modifica_position: bool = false
	var modifica_velocity: bool = false
	var modifica_color: bool = false
	var modifica_textura:bool = false
	
	for linea_raw in lineas:
		# Preservar indentación calculando espacios/tabs iniciales
		var linea_sin_magen_izq = linea_raw.lstrip(" \t")
		if linea_sin_magen_izq.is_empty() or linea_sin_magen_izq.begins_with("#"):
			continue
			
		
		# Detectar encabezados de sistemas
		if linea_sin_magen_izq.begins_with("sist inicial():") or \
			linea_sin_magen_izq.begins_with("sist bucle(dt):") or \
			linea_sin_magen_izq.begins_with("sist input():"):
			
			# Cierre del bloque previo si existía
			if en_bloque_sist:
				codigo_procesado += _generar_escritura_selectiva(modifica_position, modifica_velocity, modifica_color, modifica_textura)
			
			en_bloque_sist = true
			modifica_position = false
			modifica_velocity = false
			modifica_color = false
			modifica_textura = false
			
			# [NUEVO] Guardar la indentación del encabezado 'sist'
			indentacion_base_bloque = _contar_nivel_indentacion(linea_raw, linea_sin_magen_izq)+1
			
			if linea_sin_magen_izq.begins_with("sist inicial():"):
				codigo_procesado += "func inicial(posiciones: PackedVector2Array, velocidades: PackedVector2Array, colores: PackedColorArray, textura_indice:PackedInt32Array ) -> void:\n"
			elif linea_sin_magen_izq.begins_with("sist bucle(dt):"):
				codigo_procesado += "func bucle(posiciones: PackedVector2Array, velocidades: PackedVector2Array, colores: PackedColorArray, dt: float, textura_indice:PackedInt32Array ) -> void:\n"
			elif linea_sin_magen_izq.begins_with("sist input():"):
				codigo_procesado += "func procesar_input(event: InputEvent, posiciones: PackedVectoes: Pac2Array,ackedColorArr_custom: Array[Dictionarn], textura_indice:PackedInt32Array ) -> void:\n"
			
			# Iniciar el bucle de la entidad (Nivel 1 de indentación base)
			codigo_procesado += "\tfor ___idx in range(posiciones.size()):\n"
			codigo_procesado += "\t\tvar position: Vector2 = posiciones[___idx]\n"
			codigo_procesado += "\t\tvar velocity: Vector2 = velocidades[___idx]\n"
			codigo_procesado += "\t\tvar color: Color = colores[___idx]\n"
			#codigo_procesado += "\t\tvar vars: Dictionary = variables_custom[___idx]\n"
			codigo_procesado += "\t\tvar textura: int = textura_indice[___idx]\n"
			continue
		if en_bloque_sist:
			# Rastrear escrituras
			if "position" in linea_sin_magen_izq and ("=" in linea_sin_magen_izq or "+=" in linea_sin_magen_izq or "-=" in linea_sin_magen_izq):
				modifica_position = true
			if "velocity" in linea_sin_magen_izq and ("=" in linea_sin_magen_izq or "+=" in linea_sin_magen_izq or "-=" in linea_sin_magen_izq):
				modifica_velocity = true
			if "color" in linea_sin_magen_izq and ("=" in linea_sin_magen_izq or "+=" in linea_sin_magen_izq or "-=" in linea_sin_magen_izq):
				modifica_color = true
			if "textura" in linea_sin_magen_izq and ("=" in linea_sin_magen_izq or "+=" in linea_sin_magen_izq or "-=" in linea_sin_magen_izq):
				modifica_textura = true
			
			# [MODIFICADO] Calcular la indentación relativa respecto al 'sist'
			var nivel_linea = _contar_nivel_indentacion(linea_raw, linea_sin_magen_izq)
			var nivel_relativo = max(0, nivel_linea - indentacion_base_bloque)
			
			#codigo_procesado += indentacion_original + linea_sin_magen_izq + "\n"
			var tabs_inyectadas = "\t\t" + "\t".repeat(nivel_relativo)
			codigo_procesado += tabs_inyectadas + linea_sin_magen_izq + "\n"
			
			# Cierre del último bloque
	if en_bloque_sist:
		codigo_procesado += _generar_escritura_selectiva(modifica_position, modifica_velocity, modifica_color, modifica_textura)
	
	var plantilla_script: String = """extends RefCounted
var contexto_principal: Object

func texture_asig(texto:String, id:int) -> int:
	Input.action_press("canviar_sprite")
	Input.action_release("canviar_sprite")
	Variables.ide = id
	return Variables.spri_name.find(texto)

%s
""" % codigo_procesado
	print(plantilla_script )
	var script = GDScript.new()
	script.source_code = plantilla_script
	if script.reload() == OK:
		return script
	else:
		push_error("Error al compilar sintaxis anidada del usuario.")
		print(plantilla_script)
		return null
		

static func _normalizar_indentacion(linea_raw: String, linea_trim: String) -> String:
	var prefijo = linea_raw.substr(0, linea_raw.length() - linea_trim.length())
	# Reemplazar bloques de 4 espacios por 1 tabulación para mantener homogeneidad
	prefijo = prefijo.replace("    ", "\t")
	return prefijo

static func _contar_nivel_indentacion(linea_raw: String, linea_trim: String) -> int:
	var prefijo = linea_raw.substr(0, linea_raw.length() - linea_trim.length())
	prefijo = prefijo.replace("    ", "\t") # Convertir 4 espacios a 1 tabulación
	return prefijo.count("\t")


static func _generar_escritura_selectiva(pos: bool, vel: bool, col: bool, tex:bool ) -> String:
	var out: String = ""
	if pos:
		out += "\t\tposiciones[___idx] = position\n"
	if vel:
		out += "\t\tvelocidades[___idx] = velocity\n"
	if col:
		out += "\t\tcolores[___idx] = color\n"
	if tex:
		out += "\t\ttextura_indice[___idx] = textura\n"
	
	return out
