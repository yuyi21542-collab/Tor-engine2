extends RefCounted
class_name ECS_SISTEMAS

var canvas_rid #= get_canvas()
var space_rid #= get_world_2d().space
var builder:DynamicAtlas

func inisial(ca,spa,atclas):
	canvas_rid = ca
	space_rid = spa
	builder = atclas

var a = 0

func crear_entidades(ecs:ECS_DATOS) -> void:## crea todas las entidades
	var i = a
	a +=1
	var xform = Transform2D(deg_to_rad(ecs.rotations[i]), ecs.positions[i])
	var size:Vector2
	var shape
	ecs.numero_entidades.append(i)
	if ecs.gei(i,4) != -1:
		var x := ecs.gei(i,4)
		#print(ecs.shape_size.size())
		size = ecs.shape_size[x] / 2
		if ecs.shape_forma[x] ==0:
			shape = PhysicsServer2D.rectangle_shape_create()
		elif ecs.shape_forma[x] ==1:
			shape = PhysicsServer2D.circle_shape_create()
			PhysicsServer2D.shape_set_data(shape, size.x)
		elif ecs.shape_forma[x] ==2:
			shape = PhysicsServer2D.capsule_shape_create()
		if ecs.shape_forma[x] !=1:
			PhysicsServer2D.shape_set_data(shape, size)
	
	var visual_rid = RenderingServer.canvas_item_create()
	RenderingServer.canvas_item_set_parent(visual_rid, canvas_rid)
	RenderingServer.canvas_item_set_transform(visual_rid, xform)
	RenderingServer.canvas_item_set_z_index(visual_rid,i)
	RenderingServer.canvas_item_set_modulate(visual_rid,ecs.colores[i])
	ecs.rid_visual.append(visual_rid)
	ecs.spaser[i*9+7] = ecs.rid_visual.size()-1
	canviar_texture(i,ecs)
	
	if ecs.spaser[i*9+3] == -1:
		return
	var physics_rid = PhysicsServer2D.body_create()
	if ecs.cuerpos[ecs.gei(i,3)] == 0:
		PhysicsServer2D.body_set_mode(physics_rid, PhysicsServer2D.BODY_MODE_KINEMATIC)
	elif ecs.cuerpos[ecs.gei(i,3)] ==1:
		PhysicsServer2D.body_set_mode(physics_rid, PhysicsServer2D.BODY_MODE_STATIC)
	elif ecs.cuerpos[ecs.gei(i,3)] == 2:
		PhysicsServer2D.body_set_mode(physics_rid, PhysicsServer2D.BODY_MODE_RIGID)
	elif ecs.cuerpos[ecs.gei(i,3)] == 3:
		PhysicsServer2D.body_set_mode(physics_rid, PhysicsServer2D.BODY_MODE_RIGID_LINEAR)
	PhysicsServer2D.body_set_space(physics_rid, space_rid)
	
	if ecs.spaser[i*9+3] ==-1:
		return
	var shape_xform = Transform2D().scaled(ecs.scales[i])
	PhysicsServer2D.body_add_shape(physics_rid, shape, shape_xform)
	PhysicsServer2D.body_set_state(physics_rid, PhysicsServer2D.BODY_STATE_TRANSFORM, xform)
	ecs.rid_fisico.append(physics_rid)
	ecs.spaser[i*9+8] = ecs.rid_fisico.size()-1


func canviar_texture(id:int,ecs:ECS_DATOS):
	var texture_rid: RID = Variables.sprites[ecs.texture_indices[id]].get_rid()
	var size = Variables.sprites[ecs.texture_indices[id]].get_size()
	var src_rect: Rect2 = Rect2(size*ecs.region_position[id],size*ecs.region_size[id])
	var size_image:Vector2 = src_rect.size / 2
	var dest_rect := Rect2(size_image *ecs.scales[id] * -1, src_rect.size *ecs.scales[id])
	RenderingServer.canvas_item_add_texture_rect_region(ecs.rid_visual[id] ,dest_rect,texture_rid,src_rect)


func update(ecs:ECS_DATOS, delta: float) -> void:
	var moviles = ecs.obtener_id_con_compo(ecs.enti_comp, [ecs.tra, ecs.cuer])
	
	var body_get_state: Callable = PhysicsServer2D.body_get_state
	var body_set_state: Callable = PhysicsServer2D.body_set_state
	var canvas_item_set_transform: Callable = RenderingServer.canvas_item_set_transform
	var body_state_transform: int = PhysicsServer2D.BODY_STATE_TRANSFORM
	
	
	for i in moviles:
		var cuerpo:int = ecs.cuerpos[ecs.gei(i,3)]
		var rid_vi:RID = ecs.rid_visual[ecs.gei(i,7)]
		var rid_cu:RID = ecs.rid_fisico[ecs.gei(i,8)]
		
		var transformacion: Transform2D = body_get_state.call(rid_cu, body_state_transform)
		if cuerpo != 2:
			var nueva_pos: Vector2 = ecs.positions[ecs.gei(i,0)] + ecs.velocidades[ecs.gei(i,0)] * delta
			transformacion.x = Vector2(cos(ecs.rotations[ecs.gei(i,0)]), sin(ecs.rotations[ecs.gei(i,0)]))
			transformacion.y = Vector2(-transformacion.x.y, transformacion.x.x)
			transformacion.origin = nueva_pos
			
			if ecs.velocidades[ecs.gei(i,0)] !=Vector2.ZERO:
				body_set_state.call(rid_cu, body_state_transform, transformacion)
			ecs.positions[ecs.gei(i,0)] = nueva_pos
		else:
			ecs.positions[ecs.gei(i,0)] = transformacion.get_origin()
		canvas_item_set_transform.call(rid_vi, transformacion)
		#canvas_item_set_z_index.call(rid_vi, i)
		RenderingServer.canvas_item_set_modulate(rid_vi, ecs.colores[ecs.gei(i,2)])
