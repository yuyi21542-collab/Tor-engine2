extends RefCounted
class_name ECS_DATOS

var enti := 0

var numero_entidades:PackedInt32Array
var entidades_activas:PackedInt32Array
var entity_masks:PackedInt64Array # lista con la cantida de componente 
var spaser:PackedInt32Array

var velocidades: PackedVector2Array = []

var positions: PackedVector2Array = []
var rotations: PackedInt32Array = []
var scales: PackedVector2Array = []

var texture_indices: PackedInt32Array
var colores: PackedColorArray
var region_size: PackedVector2Array
var region_position: PackedVector2Array

var cuerpos: PackedInt32Array = []

var shape_forma: PackedInt32Array
var shape_size:PackedVector2Array
var array_de_script:PackedStringArray

var variables_custom:Array[Dictionary] = [{"vane":0}]
var enti_comp:Dictionary

var contenedor_scripts
var array = []
var grupos_arquetipos: Dictionary = {}
var instancias_scripts: Dictionary = {}

# Estructura ligera para emparejar el ID visual con el ID físico
var rid_visual:Array[RID]
var rid_fisico:Array[RID]

class UIItem:
	var visual_rid: RID
	var screen_position: Vector2

var active_ui_items: Array[UIItem] = []
var shape_rid: RID
var ui_layer_rid: RID # ID del contenedor de la interfaz

var entid:int = Variables.ide

const tra := 0
const ani := 1
const spr := 2
const cuer:= 3
const col := 4
const scr := 5
const bot := 6

# Esta función prepara el "Bitset" de una entidad
func crear_mascara_vacia() -> PackedInt64Array:
	return PackedInt64Array([0, 0])

# Función para agregar un componente a la entidad
func agregar_componente(mascara: PackedInt64Array, componente_id: int) -> PackedInt64Array:
	var indice_array = componente_id / 64 
	var posicion_bit = componente_id % 64
	
	# Si el ID es tan grande que supera el tamaño actual del array, lo expandimos
	while mascara.size() <= indice_array:
		mascara.append(0)
		
	# Encendemos el bit usando el operador OR ( | )
	mascara[indice_array] |= (1 << posicion_bit)
	return mascara

## Función ULTRA RÁPIDA para verificar si tiene el componente
func tiene_componente(mascara: PackedInt64Array, componente_id: int) -> bool:
	var indice_array = componente_id / 64
	var posicion_bit = componente_id % 64
	
	# Si el array es más chico que el índice, significa que jamás se le agregó
	if indice_array >= mascara.size():
		return false
		
	# Verificación binaria instantánea usando AND ( & )
	return (mascara[indice_array] & (1 << posicion_bit)) != 0

# 1. Función para convertir un array de IDs de componentes en una máscara de bits
func crear_mascara_requisitos(componentes_ids: Array[int]) -> PackedInt64Array:
	var mascara_req = PackedInt64Array()
	
	for id in componentes_ids:
		var indice_array = id / 64
		var posicion_bit = id % 64
		
		# Expandir la máscara si el ID requiere un bloque de 64 bits más alto
		while mascara_req.size() <= indice_array:
			mascara_req.append(0)
			
		# Encender el bit correspondiente
		mascara_req[indice_array] |= (1 << posicion_bit)
		
	return mascara_req

# 2. Función para verificar si la máscara de la entidad cumple con los mínimos
func cumple_con_minimos(entidad_mascara: PackedInt64Array, requeridos_mascara: PackedInt64Array) -> bool:
	var tam_req = requeridos_mascara.size()
	
	# Si la entidad tiene menos bloques que los requeridos, seguro le faltan componentes
	if entidad_mascara.size() < tam_req:
		return false
		
	for i in range(tam_req):
		var req = requeridos_mascara[i]
		# Si hay bits requeridos en este bloque...
		if req != 0:
			# Comprobamos con AND ( & ). 
			# Si el resultado no es exactamente 'req', significa que a la entidad le falta al menos un bit.
			if (entidad_mascara[i] & req) != req:
				return false
				
	return true

## 3. Función principal para obtener el array de entidades filtradas
func obtener_id_con_compo(todas_las_entidades: Dictionary, componentes_minimos_ids: Array[int]) -> Array:
	var requeridos_mascara = crear_mascara_requisitos(componentes_minimos_ids)
	var entidades_compatibles: Array = []
	
	for entidad in todas_las_entidades:
		# Asumiendo que cada entidad tiene una propiedad llamada 'mascara' de tipo PackedInt64Array
		if cumple_con_minimos(todas_las_entidades[entidad], requeridos_mascara):
			entidades_compatibles.append(entidad)
			
	return entidades_compatibles

func gei(id:int,componente:int) -> int:
	if id ==0:
		return spaser[id*9]
	else:
		return spaser[id*9+componente]

# --- LIMPIEZA OBLIGATORIA DE MEMORIA ---
func _exit_tree() -> void:
	# Liberar objetos del mundo físico
	for item in Variables.referencia2.size():
		RenderingServer.free_rid(rid_visual[item])
		PhysicsServer2D.free_rid(rid_fisico[item])
	if shape_rid.is_valid():
		PhysicsServer2D.free_rid(shape_rid)
	
	# Liberar objetos de interfaz
	for ui_item in active_ui_items:
		RenderingServer.free_rid(ui_item.visual_rid)
	# Liberar el canvas virtual de la UI
	if ui_layer_rid.is_valid():
		RenderingServer.free_rid(ui_layer_rid)
