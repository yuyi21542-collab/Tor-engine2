extends Node2D
#se encarga de manejar la lógica de los bloques de código

signal array_cargados()

var nuevo_final = false
var salta_al_nueve = false
var verdadero = true #salta a el codigo si es falso

var fps
var pasos_para_dar:int = 0

@onready var entida = $entidades

var funsiones: Array[Callable] = [
	recore_array,
	ejecuta_textura,
	ejecuta_color,
	ejecuta_posicion,
	ejecuta_rotasion,
	ejecuta_velosity,
	ejecuta_condision,
	ejecuta_final,
]


const tra := 1
const ani := 2
const spr := 4
const cuer:= 8
const col := 16
const scr := 32
const bot := 64


func _physics_process(_delta: float) -> void:
	fps = int(Engine.get_frames_per_second())
	%fps.text = "FPS."+str(fps)
	for id in Variables.referencia2.size():
		for dis in Variables.index_por_siempre:
			funsiones[0].call(dis,id)

var ecs:ECS_DATOS
var si_es_verdadero = Condisional.new()
var posv:Array[Vector2]


func _ready():
	ecs = $entidades.ecs
	Tur.añadir_datos.connect(recore_array_dat)
	#ecs.cuerpos.resize(101)
	for i in range(Variables.referencia2.size()):
		add_enti_vacia(i)
		for iten in Variables.inicial[str(i)].size():
			asigna_valores_array(i,Variables.inicial[str(i)][iten])
		emit_signal("array_cargados",ecs.array[i])
		#if i< ecs.array.size():
			#emit_signal("array_cargados",ecs.array[i])
		#else:
			#emit_signal("array_cargados",null)
	await get_tree().create_timer(1).timeout
	#print(ecs.spaser )
	entida.proses = true
	
	#for id in Variables.referencia2.size():
		#for nodo in Variables.index_comenzar:
			#funsiones[0].call(nodo,id)

func add_enti_vacia(i:int):
	if not ecs.enti_comp.has(i):
		ecs.enti_comp[i] = ecs.crear_mascara_vacia()
		for z in range(9):
			ecs.spaser.append(-1)


var cons = 0
var con_po = {}

func recore_array_dat(iten:Array ):
	ecs.array_de_script.append(entida.codigo_usuario)
	add_enti_vacia(cons+1)
	for i in iten.size():
		asigna_valores_array(cons+1,iten[i])
	emit_signal("array_cargados",ecs.array[cons+1])
	cons+=1


func _input(event):
	if event is InputEventScreenTouch:
		for id in Variables.referencia2.size():
			for nodo in Variables.index_input:
				funsiones[0].call(nodo,id)

func asigna_valores_array(i:int,iten:RefCounted):
	ecs.enti_comp[i] = ecs.agregar_componente(ecs.enti_comp[i],iten.ICONO)
	#ecs.spaser[i+iten.ICONO] = con_po[iten.ICONO]
	var cs = 0
	if i >0:
		cs = i *9
	if iten is Transform:
		ecs.velocidades.append(Vector2.ZERO)
		ecs.positions.append(Vector2(iten.pos_x,iten.pos_y))
		ecs.rotations.append(iten.rotasion)
		ecs.scales.append(Vector2(iten.scala_x,iten.scala_y))
		ecs.spaser[cs] = ecs.scales.size()-1
		return
	
	if iten is CuerpoFisico:
		ecs.cuerpos.append(int(iten.cuerpo))
		ecs.spaser[cs+iten.ICONO] = ecs.cuerpos.size()-1
		return
	
	if iten is Sprite:
		ecs.colores.append(iten.color)
		ecs.region_size.append(iten.region.size)
		ecs.region_position.append(iten.region.position)
		ecs.texture_indices.append(0)
		ecs.spaser[cs+iten.ICONO] = ecs.colores.size()-1
		#return
	
	if iten is Colision:
		ecs.shape_size.append(Variables.sprites[ecs.texture_indices[i]].get_size())
		ecs.shape_forma.append(iten.formas)
		ecs.spaser[cs+iten.ICONO] = ecs.shape_forma.size()-1
		#return
	
	if iten is Scritps:
		#ecs.add_component(i,scr)
		var id_script = ecs.array_de_script[i].hash()
		ecs.array.append(id_script)
		ecs.spaser[cs+iten.ICONO] = ecs.array.size()-1
		if not ecs.instancias_scripts.has(id_script):
			var gdscript_compilado = CompiladorComportamientoECS.compilar_script_entidad(ecs.array_de_script[i])
			if gdscript_compilado:
				var instancia = gdscript_compilado.new()
				instancia.set("contexto_principal", self)
				ecs.instancias_scripts[id_script] = instancia
				ecs.grupos_arquetipos[id_script] = []
				ecs.grupos_arquetipos[id_script].append(i)
	

func recore_array(nodo:int,id:int):
	var con:int = 0
	var valor:int = 0
	for iten in Variables.claves_para_script.size()-nodo:
		if Variables.claves_para_script[con+nodo] >2:
			valor = Variables.claves_para_script[con+nodo] -2
			if verdadero and not nuevo_final:
				funsiones[valor].call(con+nodo, id)
			if nuevo_final and not verdadero:
				funsiones[valor].call(con+nodo, id)
			
		if con < Variables.claves_para_script.size():
			con+=1

func ejecuta_textura(nodo,id):
	entida.cambiar_textura_de_entida(entida.rid_visual[id],Variables.valores_para_script[nodo][0],id)
	entida.texture_indices[id] = Variables.valores_para_script[nodo][0]


func ejecuta_color(nodo,id):
	entida.colores[id] = Variables.valores_para_script[nodo][0]

func ejecuta_posicion(nodo,id):
	entida.positions[id] = Variables.valores_para_script[nodo][0]

func ejecuta_rotasion(nodo,id):
	entida.rotations[id] = Variables.valores_para_script[nodo][0]

func ejecuta_velosity(nodo,id):
	entida.velocidades[id] = Variables.valores_para_script[nodo][0]

func ejecuta_condision(nodo,id):
	var texto:String =  Variables.valores_para_script[nodo][0]
	si_es_verdadero.compile(texto)
	var xform = Transform2D(deg_to_rad(entida.rotations[id]), entida.positions[id])
	var vel = entida.velocidades[id]
	verdadero = si_es_verdadero.evaluate(xform,vel)
	nuevo_final = not verdadero
	

func ejecuta_final(_nodo,_id):
	verdadero = false
	return

func _on_salir_pressed() -> void:
	Variables.modo_de_edision = "no_as_nada"
	get_tree().call_deferred("change_scene_to_file","res://ventana.tscn")
