extends Node2D

var bloque = load("res://Escenas/nodo_base.tscn")
var contador = 0
var sensibilidad = 1
var guardar_si_no = true
var arrastrando = true
var guardar:String = Variables.modo_de_edision
var viupor:Vector2 = Vector2(1172,655)
var Transfor = null
var refe_nodos = []
var prue = []
var guardar_nodos = []
var colores:Array = [Color.RED,Color.BLUE,Color.BLUE_VIOLET]

@export var lista_input :Array[String]
@onready var editor = $ui_mover/visual
@export var camera:Camera2D

signal actualizar_inspector()

#rid de las entidades
var rid_colisiones:Array[RID]
var rid_entida:Array[RID]

func _input(event):
	if Variables.referencia2.size()>0 and Variables.ide_objeto !="" and not event is InputEventScreenDrag:
		if not Variables.limit:
			recarga_entida_selesionada()
	
	if event is InputEventScreenDrag and editor.arastra and editor.visible and editor.numero_selected()<1:
		$ui_mover/visual.scroll_offset -= event.relative
	
	if event is InputEventScreenTouch or InputEventScreenDrag and not InputEventKey:
		if event.position.x <viupor.x and event.position.y <viupor.y:
			Variables.limit = true
		else:
			Variables.limit = false
	if Input.is_action_just_pressed("asigna una textura"):
		var scala = Vector2(1,1)
		var id:RID = rid_entida[Variables.ide]
		var clase:Sprite = Variables.optener_componente("Sprite")
		var textura:Texture2D
		var tex_size:Vector2
		if clase.textura !="":
			textura = load(clase.textura)
			tex_size = textura.get_size()
			var c := tex_size * clase.region.position
			var a := tex_size * clase.region.size
			var x = a/2
			var rec:= Rect2(x*scala*-1 , a*scala)
			var rec_size := Rect2(c,a)
			RenderingServer.canvas_item_clear(id)
			RenderingServer.canvas_item_add_texture_rect_region(id,rec,textura.get_rid(),rec_size)
	
	if Input.is_action_just_pressed("editar"):
		Variables.modo_de_edision = "editar"
	if Input.is_action_just_pressed("Mover"):
		Variables.modo_de_edision = "mover"
	if Input.is_action_just_pressed("Scalar"):
		var tipo = ["scala.x","scala.y","scala.xy"]
		if event is InputEventScreenTouch:
			if contador ==3:
				contador =0
			if contador <3:
				contador +=1
				Variables.modo_de_edision = tipo[contador-1]
				
	if Input.is_action_just_pressed("Rotar"):
		Variables.modo_de_edision ="rotar"
	if Input.is_action_just_pressed("guardar") and guardar_si_no:
		guardar_si_no = false
		obtener_lista_nombres_ordenada()
		await get_tree().create_timer(0.5).timeout
		guardar_si_no = true
	if Input.is_action_just_pressed("borrar el nodo"):
		var con:= 0
		for i in refe_nodos:
			if i.borrar:
				i.queue_free()
				refe_nodos.remove_at(con)
			con+=1
	if Variables.limit and Variables.ide_objeto !="" and Variables.optener_componente("Transform"):
		var compo:Transform = Variables.optener_componente("Transform")
		if event is InputEventScreenDrag:
			if Variables.modo_de_edision =="mover":
				compo.pos_x += event.relative.x * sensibilidad
				compo.pos_y += event.relative.y * sensibilidad
			if Variables.modo_de_edision =="rotar":
				compo.rotasion += event.relative.y * 0.5
			if Variables.modo_de_edision =="scala.x" or "scala.y" or "scala.xy":
				#if Variables.modo_de_edision =="rotar":return
				
				var factor = (event.relative.x - event.relative.y) * 0.1
				if Variables.modo_de_edision=="scala.x":
					compo.scala_x += factor
				if Variables.modo_de_edision=="scala.y":
					compo.scala_y += factor
				if Variables.modo_de_edision == "scala.xy":
					compo.scala_x += factor
					compo.scala_y += factor
				if compo.scala_x <= 0.1 and Variables.modo_de_edision != "rotar":
					compo.scala_x = 0
				
			recarga_entida_selesionada()
			if Variables.optener_componente("Colision"):
				recarga_tras_colisiones()
		if event is InputEventScreenTouch:
			emit_signal("actualizar_inspector")
			#if Variables.optener_componente("Colision"):
				#reca_valores_colision()
			

func crea_colision():
	var xform:Transform2D = crea_Transfor2d(Variables.optener_componente("Transform"))
	var coli_color:Color = Variables.optener_componente("Colision").color
	var id:int
	rid_colisiones.append(RenderingServer.canvas_item_create())
	RenderingServer.canvas_item_set_parent(rid_colisiones[id], get_canvas_item())
	RenderingServer.canvas_item_set_transform(rid_colisiones[id], xform)
	RenderingServer.canvas_item_set_z_index(rid_colisiones[id],10)
	var posicion:Vector2
	var tamano:Vector2 = Vector2(90,90)
	coli_color.a = 0.4
	
	# Le ordenamos a la GPU que dibuje un rectángulo directamente en memoria de video
	var rect = Rect2(posicion - tamano / 2, tamano)
	RenderingServer.canvas_item_add_rect(rid_colisiones[id], rect, coli_color)

func recarga_tras_colisiones():
	if rid_colisiones.size()<= Variables.ide:
		return
	
	var rid:RID = rid_colisiones[Variables.ide]
	var xform:Transform2D = crea_Transfor2d(Variables.optener_componente("Transform"))
	RenderingServer.canvas_item_set_transform(rid, xform)


func reca_valores_colision():
	var coli:Colision = Variables.optener_componente("Colision")
	var rid:RID = rid_colisiones[Variables.ide]
	var posicion:Vector2
	var tamano:Vector2 = Vector2(coli.ancho,coli.alto)
	
	RenderingServer.canvas_item_clear(rid)
	if coli.formas ==0:
		var rect = Rect2(posicion - tamano / 2, tamano)
		RenderingServer.canvas_item_add_rect(rid, rect, coli.color)
	elif coli.formas ==1:
		RenderingServer.canvas_item_add_circle(rid,posicion,tamano.x/2,coli.color)
 
func mover_punto():
	var pi:Vector2
	var trans = Variables.optener_componente("Transform")
	var bo:bool = false
	if Variables.inicial.has(str(Variables.ide))and trans:
		bo = true
		pi.x = trans.pos_x
		pi.y = trans.pos_y
	var rid_global_position: Vector2 = global_transform * pi
	
	# 3. Extraemos de forma segura la matriz de la cámara y el zoom desde el Viewport
	var canvas_transform: Transform2D = get_viewport().get_canvas_transform()
	# 4. Multiplicamos para obtener la posición final en píxeles de la pantalla
	var posicion_en_pantalla: Vector2 = canvas_transform * rid_global_position
	$ui_mover/pu.visible = bo
	$ui_mover/pu.position = posicion_en_pantalla -$ui_mover/pu.size/2

func crear_entidad():
	var id:int 
	rid_entida.append(RenderingServer.canvas_item_create())
	RenderingServer.canvas_item_set_parent(rid_entida[id], get_canvas_item())

func recarga_entida_selesionada():
	if not Variables.inicial.has(str(Variables.ide)):
		return
	
	var id:RID = rid_entida[Variables.ide]
	var lista_componentes:Array = Variables.inicial[str(Variables.ide)]
	
	for tipe in lista_componentes:
		tipo_compotente(id,tipe)

func tipo_compotente(id:RID, tipe):
	if tipe.nombre_componentes =="Transform":
		var sca := Vector2(tipe.scala_x,tipe.scala_y)
		var pos := Vector2(tipe.pos_x,tipe.pos_y)
		var xform:= Transform2D(deg_to_rad(tipe.rotasion),sca,0,pos)
		mover_punto()
		RenderingServer.canvas_item_set_transform(id, xform)
		return
	if tipe.nombre_componentes =="Sprite":
		var clase:Sprite = tipe
		RenderingServer.canvas_item_set_modulate(id, clase.color)
		

func crea_Transfor2d(iten:Transform) -> Transform2D:
	var tra: = Transform2D(deg_to_rad(iten.rotasion),Vector2(iten.scala_x,iten.scala_y),0,Vector2(iten.pos_x,iten.pos_y))
	return tra

func demostracion(_base:String):
	crear_entidad()

func _draw() -> void:
	var mo:Color = Color(1.0, 1.0, 1.0, 1.0)
	var vi:Vector2 = Vector2(1550,720)
	var visulisar := Rect2(-vi.x/2, -vi.y/2, vi.x, vi.y)
	draw_rect(visulisar, mo, false )#dibuja el rectángulo de la camara
	
	draw_line(Vector2(0,-100000),Vector2(0,100000),Color.DODGER_BLUE,2,false)
	draw_line(Vector2(-100000,0),Vector2(100000,0),colores[0],2,false)

func _ready():
	
	for i in $ui_mover/f.get_children():
		if i is TextureButton:
			i.pressed.connect(boton_textura.bind(i.name,i.position.x))
	for i in Variables.referencia2.size():
		return

func crear_nodo(nombre):
	var edit = bloque.instantiate()
	edit.mode = nombre
	edit.name = nombre
	editor.add_child(edit)
	edit.name = nombre
	refe_nodos.append(edit)

func eliminar_nodos():
	for i in refe_nodos:
		if is_instance_valid(i):
			i.queue_free()
	refe_nodos.clear()
	prue.clear()

func recargar_nodos():
	var clave = str(Variables.ide) + Variables.editando_el_script
	var lista = Variables.block_script[clave]
	var prod
	for i in lista.size():
		var opp = bloque.instantiate()
		opp.name = lista[i]
		prod = lista[i]
		var regex = RegEx.new()
		regex.compile("\\d")
		var resul = regex.sub(prod,"",true)
		opp.mode = resul
		if Variables.lis_requisitos.size() > 1:
			if opp.name == Variables.lis_requisitos[2]:
				Variables.scrit_nodos[clave][lista[i]][0] = Variables.lis_requisitos[3]
		opp.position_offset = Variables.nodos_posiciones[clave][i]
		editor.add_child(opp)
		opp.valor = Variables.scrit_nodos[clave][lista[i]][0]
		refe_nodos.append(opp)
	if Variables.conexiones[clave] != null:
		restore_connections(Variables.conexiones[clave])

func restore_connections(connections: Array):
	for conn in connections:
		var from_node = conn["from_node"]
		var from_port = conn["from_port"]
		var to_node = conn["to_node"]
		var to_port = conn["to_port"]
		editor.connect_node(from_node, from_port, to_node, to_port)

## Función para obtener la lista de nombres en orden de conexión
func obtener_lista_nombres_ordenada():
	var nombre = str(Variables.ide) +Variables.editando_el_script
	Variables.block_script[nombre].clear()
	Variables.nodos_posiciones[nombre].clear()
	Variables.scrit_nodos[nombre] = {}
	Variables.block_script_global[nombre].clear()
	Variables.script_globales[nombre] = {}
	Variables.conexiones[nombre].clear()
	Variables.claves_para_script.clear()
	Variables.valores_para_script.clear()
	Variables.index_comenzar.clear()
	Variables.index_por_siempre.clear()
	
	var conexiones = editor.get_connection_list()
	Variables.conexiones[nombre] = conexiones
	var ruta_nombres = editor.generar_disionario()
	
	var se:int = 0
	var regex = RegEx.new()
	for def in ruta_nombres:
		regex.compile("\\d")
		var resul = regex.sub(def,"",true)
		Variables.claves_para_script.append(editor.id_nodo.find(resul))
		if Variables.claves_para_script[se] ==0:
			Variables.index_comenzar.append(ruta_nombres.find(def))
		if Variables.claves_para_script[se] ==1:
			Variables.index_por_siempre.append(ruta_nombres.find(def))
		if Variables.claves_para_script[se] ==2:
			Variables.index_input.append(ruta_nombres.find(def))
		
		se +=1
	
	var pri =[]
	var v = 0
	for i in refe_nodos.size():
		pri.append(refe_nodos[i].name)
	for i in ruta_nombres.size():
		v = pri.find(ruta_nombres[i])
		prue.append(refe_nodos[v])
	for s in refe_nodos.size():
		Variables.block_script[nombre].append(str(refe_nodos[s].name))
		Variables.scrit_nodos[nombre][str(refe_nodos[s].name)] = [refe_nodos[s].valor]
		Variables.nodos_posiciones[nombre].append(refe_nodos[s].position_offset)
	for iten in Variables.claves_para_script.size():
		Variables.valores_para_script.append([prue[iten].valor, prue[iten].componente])

func _on_visual_connection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	editor.connect_node(from_node,from_port,to_node,to_port)

func _on_visual_disconnection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	editor.disconnect_node(from_node, from_port, to_node, to_port)

func boton_textura(na:String,x:float):
	%se.position.x = x
	Input.action_press(na)
	Input.action_release(na)

func _on_conten_datos_actualizar_propiedades(clase: String) -> void:
	if clase =="Colision":
		reca_valores_colision()
		recarga_tras_colisiones()
	elif clase =="Transform":
		recarga_entida_selesionada()
		recarga_tras_colisiones()
	#elif clase =="Sprite":
		
		
	
