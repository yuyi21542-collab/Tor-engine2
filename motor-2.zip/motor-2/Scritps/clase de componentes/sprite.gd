class_name Sprite
extends RefCounted

#valores del componente en el editor
const ICONO := 2
var nombre_componentes := "Sprite"
var colapsado := false

#propiedades unicas del componente
var visible: bool = true
var textura: String = ""
var color: = Color(1.0, 1.0, 1.0, 1.0)
var region: = Rect2(0,0,1.0,1.0)
