extends RefCounted
class_name CuerpoFisico

#valores del componente en el editor
const ICONO := 3
var nombre_componentes := "Cuerpo Fisico"
var colapsado := false

@export_enum ("Kinematico","Estatico","Rigibody") var cuerpo:int = 0
var masa:float = 1.0
var frision:float = 0.0
var rebote:float = 0.0
var detecta:bool = true
