extends RefCounted
class_name Colision

#valores del componente en el editor
const ICONO := 4
var nombre_componentes := "Colision"
var colapsado := false

@export_enum ("Cuadrado","Circulo","Capsula") var formas:int = 0
var color:Color = Color(0.272, 0.85, 0.532, 1.0)
var ancho:float = 90
var alto:float = 90
