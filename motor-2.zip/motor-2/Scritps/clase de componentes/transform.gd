extends RefCounted
class_name Transform

#valores del componente en el editor
const ICONO := 0
var nombre_componentes := "Transform"
var colapsado := false

var rotasion:= 0
var pos_x:= 0
var pos_y:= 0
var scala_x:= 1.0
var scala_y:= 1.0
