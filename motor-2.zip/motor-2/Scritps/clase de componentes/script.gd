extends RefCounted
class_name Scritps

#valores del componente en el editor
const ICONO := 5
var nombre_componentes := "Scritps"
var colapsado := false

var nombre:String= "script"
