extends RefCounted
class_name Boton

#valores del componente en el editor
const ICONO := 6
var nombre_componentes := "Boton Color"
var colapsado := false

var normal:= Color.WHITE
var pressed:= Color.AQUA
var activo:= Color.RED
var esquinas:= 1
var ancho:= 50
var alto:= 50
