extends VBoxContainer

var tipos = "nada"
var segundo:int
var indice:int#tipo_de_material
var colision
var inden:int = 0
var dimensiones:Vector2
var tiene_textura = [false, false, false]
var sprite_dimensiones

var transform:PackedFloat32Array 
var forma:Array = [RectangleShape2D,CircleShape2D,CapsuleShape2D]

signal actualizar_boton
signal actualizar_textura(icono,lugar)

func nombra_propiedades(estado):
	
	match estado:
		0:
			$Label7.text = "  rotacion"
			$Label3.text = "  pos.x"
			$Label4.text = "  pos.y"
			$Label5.text = "  sca.x"
			$Label6.text = "  sca.y"
		1:
			$Label7.text = "  frem"
			
		2:
			$Label8.text = "  color"
			$Label5.text = "  ancho"
			$Label6.text = "  alto"
		3:
			$cuerpos.text = "  cuerpos"
			$Label7.text = "  gravedad"
			$Label3.text = "  frision"
			$Label4.text = "  masa"
		4:
			inden = Variables.inicial[str(Variables.ide) +"colision"][0]
			$cuerpos.text = "  forma"
			$Label9.text = "  detecta"
			$Label5.text = "  ancho"
			$Label6.text = "  alto"
		5:
			$Label7.text = "  nombre"
		6:
			$Label7.text = "  normal"
			$Label3.text = "  presionado"
			$Label4.text = "  activo"
			$Label8.text = "  redondear"
			$Label5.text = "  ancho"
			$Label6.text = "  alto"


func asigna_una_textura():
	if tipos != "nada":
		var ruta = "textu" + str(tipos)
		get_node(ruta + "/acopla").icon = Variables.sprites[Variables.sprite_a_canviar]
		get_node(ruta + "/n/boton").text = ""
		get_node(ruta + "/n/boton").icon = Variables.sprites[Variables.sprite_a_canviar]
		get_node(ruta + "/n/boton").icon_alignment = 1
		get_node(ruta + "/n/boton").set("theme_override_constants/icon_max_width", 100)
		emit_signal("actualizar_textura",get_node(ruta+"/acopla").icon, int(tipos))

func eliminar(vi):
	$textu1.visible = vi
	$textu2.visible = vi
	$textu3.visible = vi
	$Label7/color.visible = vi
	$Label3/color.visible = vi
	$Label4/color.visible = vi

func eliminar_esconder_nodos():
	segundo = 6
	$textu1.visible = false
	$textu2.visible = false
	$textu3.hide()
	$Label9.hide()
	$sprite.hide()
	if segundo == 6:
		esconder("tip escribir","tip color")

func esconder(texto1, texto2):
	for nodo in find_children("","Control",true):
		if nodo.is_in_group(texto1):
			nodo.hide()
	for nodo in find_children("","Control",true):
		if nodo.is_in_group(texto2):
			nodo.show()

func _on_boton_pressed() -> void:
	Input.action_press("canviar_sprite")
	Input.action_release("canviar_sprite")
	tipos = "1"
func _on_boton_2_pressed() -> void:
	Input.action_press("canviar_sprite")
	Input.action_release("canviar_sprite")
	tipos = "2"
func _on_boton_3_pressed() -> void:
	Input.action_press("canviar_sprite")
	Input.action_release("canviar_sprite")
	tipos = "3"


func _on_option_item_selected(index: int) -> void:
	if segundo ==6:
		match index:
			0:
				$Label7.visible = true
				$Label3.visible = true
				$Label4.visible = true
				esconder("tip escribir","tip color")
			1:
				$Label7.visible = false
				$Label3.visible = false
				$Label4.visible = false
				esconder("tip color","tip escribir")
				
		emit_signal("actualizar_boton")
	if indice ==3:
		Variables.inicial[str(Variables.ide) +"cuerpos"][0] = index
	if indice ==4:
		Variables.inicial[str(Variables.ide) +"colision"][0] = index
	inden = index
	canviar_forma_colision()


func canviar_forma_colision():
	if indice ==4:
		Variables.inicial[str(Variables.ide) +"colision"][3] = forma[inden].new()
		var dino = Variables.inicial[str(Variables.ide) +"colision"][3]
		match inden:
			0:
				dino.size = Vector2(92,92)
				colision.shape = dino
				$Label6.show()
				$Label5/TextEdit.text = str(92)
			1:
				dino.radius = 46
				colision.shape = dino
				$Label6.hide()
				$Label5/TextEdit.text = str(92)
			2:
				dino.height = 92
				dino.radius = dino.height / 4
				colision.shape = dino
				$Label6.show()
				$Label5/TextEdit.text = str(int(dino.radius))
		#$Label6/TextEdit.text = str(92)
		Variables.inicial[str(Variables.ide) +"colision"][3] = colision.shape


func actualizar_tamaño():
	Variables.inicial[str(Variables.ide)+"colision"][3] = forma[inden].new()
	var tamaño = Variables.inicial[str(Variables.ide) +"colision"][3]
	if inden ==0:
		tamaño.size = dimensiones
		colision.shape = tamaño
	elif inden ==1:
		tamaño.radius = dimensiones.x / 2
		colision.shape = tamaño
	elif inden ==2:
		tamaño.height = dimensiones.y
		tamaño.radius = tamaño.height/ 4
		colision.shape = tamaño
	Variables.inicial[str(Variables.ide) +"colision"][3] = colision.shape
	#tamaño = null
	
