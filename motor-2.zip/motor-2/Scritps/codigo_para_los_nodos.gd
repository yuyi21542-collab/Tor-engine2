extends GraphEdit

var arastra:bool = true

var id_nodo = [
	"comenzar",
	"por siempre",
	"cuando toque",
	"texture",
	"modulate",
	"position",
	"rotation",
	"velocity",
	"si es verdadero",
	"final",
]

func numero_selected():
	var con = 0
	for nodo in get_children():
		if nodo is GraphNode and nodo.selected:
			con += 1
	return con

func generar_disionario() -> Array:
	var lista_final = []
	var conexiones = get_connection_list()
	
	# 1. Identificar nodos que reciben conexiones
	var nodos_con_entrada = []
	for con in conexiones:
		nodos_con_entrada.append(con.to_node)
		
	var entradas_validas = []
	for nodo in get_children():
		if nodo is GraphNode:
			var tiene_salida = false
			for con in conexiones:
				if con.from_node == nodo.name:
					tiene_salida = true
					break
					
			if not nodos_con_entrada.has(nodo.name) and tiene_salida:
				entradas_validas.append(nodo)
	
	for nodo_raiz in entradas_validas:
		if not lista_final.has(str(nodo_raiz.name)):
			lista_final.append(str(nodo_raiz.name))
			
		_rastrear_por_puertos(str(nodo_raiz.name), conexiones, lista_final)
	return lista_final



func _rastrear_por_puertos(nombre_padre:StringName, conexiones:Array, lista:Array):
	var puertos_ocupados = {}
	
	for con in conexiones:
		if con.from_node == nombre_padre:
			var puerto_origen = con.from_port
			if not puertos_ocupados.has(puerto_origen):
				puertos_ocupados[puerto_origen] = []
			puertos_ocupados[puerto_origen].append(con.to_node)
	
	if puertos_ocupados.is_empty():
		return
	
	var lista_puertos = puertos_ocupados.keys()
	lista_puertos.sort()
	
	for puerto in lista_puertos:
		
		var nombre_puerto = "final"
		if puerto > 0:
			lista.append(nombre_puerto)
		
		# Agregamos los nodos conectados a ese puerto y seguimos su rastro
		for nodo_hijo in puertos_ocupados[puerto]:
			var nombre_hijo = str(nodo_hijo)
			lista.append(nombre_hijo)
			
			# Recursión: buscar los hijos de este nodo
			_rastrear_por_puertos(nombre_hijo, conexiones, lista)


func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			var click_posicion_lienzo = event.position + scroll_offset
			
			if not _is_clicking_a_node(click_posicion_lienzo):
				get_viewport().set_input_as_handled()

func _is_clicking_a_node(click_position: Vector2) -> bool:
	for child in get_children():
		if child is GraphNode:
			# Obtenemos el rectángulo visible del GraphNode en el espacio local del GraphEdit
			var node_rect = Rect2(child.position_offset, child.size)
			
			# Si la posición del clic está dentro de las dimensiones del nodo
			if node_rect.has_point(click_position):
				return true
			else:
				child.selected = false
			
	return false


func _on_connection_drag_started(_from_node: StringName, _from_port: int, _is_output: bool) -> void:
	arastra = false
func _on_connection_drag_ended() -> void:
	arastra = true
