extends Control

@onready var base:CarpetasDesplegable = $entidades

var pos:Vector2
var dentro:bool
var names_componente:Array[String] = ["transform","animation","sprite","cuerpo fisico","colision","script","boton"]
var array_componentes:Array= [Transform,0,Sprite,CuerpoFisico,Colision,Scritps,Boton]

signal actualizar_compotente(ti)
signal añadir_entida_ala_esena(tipo:String)
signal añadir_componente(tipo:int)

func crear_array_componetes(tipo:int):
	var id:String = str(Variables.ide)
	if Variables.inicial.has(id):
		Variables.inicial[id].append(array_componentes[tipo].new())
	
	emit_signal("actualizar_compotente",tipo)

func _on_desp_crear(boton: String,clase:int) -> void:
	var se = int(boton)
	var des = 3
	var nombre:String
	if clase==0:
		nombre = "entida" + str(Variables.referencia2.size()+1)
		Variables.en_activos.append(1)
		Variables.referencia2.append(nombre)
		crear_clase_base(boton)
		emit_signal("añadir_entida_ala_esena",boton)
	else:
		crear_array_componetes(se)
		return
		#des = se +8
		#nombre = names_componente[se]
		#crear_la_vase_de_datos(se,true)
	
	base.add_entida_esena(nombre,des,Color.WHITE)


func crear_clase_base(plantiya):
	var ide:String = str(base.vara_entidades.size()-1)
	if plantiya == "3":
		Variables.inicial[ide] = [Transform.new()]
	if plantiya =="4":
		Variables.inicial[ide] = [0,2,3,4]
	if plantiya =="2":
		Variables.inicial[ide ] = [0,4]

func _on_entidades_item_selected() -> void:
	var coco = Variables.referencia2.find(base.retorna_texto())
	if coco != -1:
		Variables.ide = Variables.referencia2.find(base.retorna_texto())
		Variables.ide_objeto = Variables.referencia2[Variables.ide]
		if Variables.inicial.has(str(Variables.ide)):
			emit_signal("añadir_componente",coco)
