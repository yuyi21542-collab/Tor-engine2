@icon("res://sprites/hierarchy.png")
## nodo para facilitar la creación de carpetas de forma gerarjica

extends Tree
class_name CarpetasDesplegable

@export var color_pri:Color 
@export var carpeta_selet:Color = Color(0.22, 0.22, 0.22, 1.0)
@export var icon:int = 3
@export var carpeta_defaul:String
@export var editable:bool = false
@export var nombre_hijos:Array[String]

var icono = load("res://sprites/atclas textura2.png")
var ico = load("res://sprites/folder.png")

var int_id:int 
var vara_entidades:Array[TreeItem] = []
var contenedor_hijos:Dictionary
var iten_padre:TreeItem

var esta_presionado: bool = false
var tiempo_presionado: float = 0.0
const TIEMPO_REQUERIDO: float = 0.6

signal canviar_estado_vara(tex:String,nu:int )

class valores_por_iten:
	var id:int# del texto
	var icon:int
	var id_padre:int# indice del padre


func _ready() -> void:
	hide_root = true
	var cor := get_theme_stylebox("hovered_selected")
	cor.bg_color = carpeta_selet
	cor.corner_radius_top_left = 8
	cor.corner_radius_top_right = 8
	cor.corner_radius_bottom_left = 8
	cor.corner_radius_bottom_right = 8
	add_theme_stylebox_override("hovered_selected",cor)
	add_theme_stylebox_override("selected",cor)
	add_theme_stylebox_override("the",cor)
	#add_entida_esena(carpeta_defaul,icon,Color.SPRING_GREEN)
	item_edited.connect(_on_item_editing_finished)
	empty_clicked.connect(desaser_toque)
	if nombre_hijos.size()==0:
		return
	
	for i in nombre_hijos.size():
		add_entida_esena(nombre_hijos[i],icon,color_pri)
		
	

func desaser_toque(_toc:Vector2, _inx:int):
	deselect_all()

func _on_item_editing_finished() -> void:
	var iten = get_edited()
	if iten:
		iten.set_editable(0, false)

func textura_region(numero: int) -> AtlasTexture:
	var columnas=8
	var tamano_celda= Vector2(30,30)
	var columna = numero % columnas
	var fila := floori(float(numero) / columnas)
	var nueva_textura := AtlasTexture.new()
	nueva_textura.atlas = icono # Textura base del Atlas
	
	nueva_textura.region = Rect2(Vector2(columna, fila) * tamano_celda, tamano_celda)
	return nueva_textura

func add_entida_esena(texto:String, clase:int, color:Color):
	var id:int = int_id
	var root: TreeItem
	
	if get_selected():
		
		vara_entidades.append(create_item(get_selected()))
		if clase>7:
			vara_entidades.back().set_icon_modulate(0,Color(0.0, 0.7, 1.0, 1.0))
		
		var iten = valores_por_iten.new()
		iten.id = Variables.referencia2.find(texto)
		iten.icon = clase
		iten.id_padre = vara_entidades.find(get_selected())
		Variables.lista_de_iten.append(iten)
	elif id ==0:
		root = create_item()
		vara_entidades.append(create_item(root))
		iten_padre = root 
		vara_entidades[id].set_icon_modulate(0,color)
	else:
		var padre = iten_padre
		vara_entidades.append(padre.create_child())
		vara_entidades[id].set_icon_modulate(0,color)
	
	vara_entidades[id].set_text(0, texto)
	if clase !=-1:
		vara_entidades[id].set_icon(0, textura_region(clase))
	else:
		vara_entidades[id].set_icon(0, ico)
	
	int_id +=1

func _process(delta: float) -> void:
	if esta_presionado :
		tiempo_presionado += delta
		if tiempo_presionado >= TIEMPO_REQUERIDO and not Teclado.esta_el_teclado_activo():
			esta_presionado = false
			
			var ite := get_selected()
			if ite:
				var mouse_pos = get_local_mouse_position()
				if get_item_at_position(mouse_pos) == ite:
					vara_estado_color(ite.get_icon_modulate(0))

func _input(event):
	if event is InputEventScreenTouch or (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT):
		
		var pos_local = make_input_local(event).position
		var celdas_rect = Rect2(Vector2.ZERO, size)
		
		if event.pressed and celdas_rect.has_point(pos_local):
			
			var caja:Vector2
			caja = Vector2(1220,70)
			caja = Vector2(20,70)
			
			var area_esquina = Rect2(caja, Vector2(150, size.y))
			
			if area_esquina.has_point(event.position):
				
				esta_presionado = false
				tiempo_presionado = 0.0
				
				var iten = get_selected()
				if iten and editable:
					# Hacemos el ítem editable
					iten.set_editable(0, true)
					# Iniciamos la edición de inmediato
					edit_selected() 
				return
			
			
			if not Teclado.esta_el_teclado_activo():
				# Validamos que estemos tocando exactamente el ítem seleccionado
				var item_bajo_el_dedo = get_item_at_position(pos_local)
				if item_bajo_el_dedo and item_bajo_el_dedo == get_selected():
					esta_presionado = true
					tiempo_presionado = 0.0
		else:
			esta_presionado = false
	if event is InputEventScreenDrag:
		esta_presionado = false
		tiempo_presionado = 0.0

func vara_estado_color(ig:Color):
	var tex:String= "entida"
	var nu:int
	match ig:
		Color.SPRING_GREEN:#esenas
			tex = "entida"
		Color(0,0.7,1,1):#componentes
			pass
		Color(1, 1, 1, 1):#entidades
			tex = "componentes"
			nu=1
	
	emit_signal("canviar_estado_vara",tex,nu)

func retor_indice_selec() -> int:
	var nodo:TreeItem = get_selected()
	return vara_entidades.find(nodo)

func retorna_texto() -> String:
	var nodo:TreeItem = get_selected()
	return nodo.get_text(0)
