extends Panel

@onready var col = $color

signal color_elegido_movil(color: Color)
signal final_bara()

var imagen_datos: Image
var color: = Color.RED

func restablecer_color():
	color = Color.RED
	$vara.value = 0
	$s.value = 0
	$v.value = 100
	$a.value = 255
	$pre.color = Color.WHITE

func _ready():
	imagen_datos = col.texture.get_image()
	$s.value_changed.connect(vara_input)
	$v.value_changed.connect(vara_input)
	$a.value_changed.connect(vara_input)

func _process(_delta):
	$pre.color.s = $s.value / 100
	$pre.color.v = $v.value / 100
	$pre.color.a = $a.value / 255

func vara_input(value) -> void:
	var pos:= Vector2($vara.value,40)
	var color_pixel : Color = imagen_datos.get_pixelv(pos)
	color = color_pixel
	
	$pre.color = color_pixel
	$pre.color.s = $s.value / 100
	$pre.color.v = $v.value / 100
	$pre.color.a = $a.value / 255
	color_pixel = $pre.color
	emit_signal("color_elegido_movil", color_pixel)


func _input(event: InputEvent) -> void:
	vara_input(1)
	
	if event is InputEventScreenTouch:
		var rec= Rect2(position,size)
		if not rec.has_point(event.position) and not Input.is_action_just_pressed("mostrar_bara_color"):
			hide()
			emit_signal("final_bara")
	
	if Input.is_action_just_pressed("mostrar_bara_color"):
		show()
	
