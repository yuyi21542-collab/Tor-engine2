class_name Condisional

var expression: Expression = Expression.new()
var is_valid: bool = false

# Definimos las propiedades expuestas al usuario del Visual Script
const VAR_MAP = {
	"position.x": "pos_x",
	"position.y": "pos_y",
	"velocity.x": "vel_x",
	"velocity.y": "vel_y",
	"rotation": "rot"
}

# Compila la condición ingresada en el nodo del visual script
func compile(condition_text: String) -> bool:
	var parsed_text = condition_text
	
	# Reemplazamos propiedades como "position.x" por "pos_x"
	for key in VAR_MAP.keys():
		parsed_text = parsed_text.replace(key, VAR_MAP[key])
	# Las variables que Expression esperará en el arreglo de entradas
	var input_names = PackedStringArray(VAR_MAP.values())
	
	var error = expression.parse(parsed_text, input_names)
	is_valid = (error == OK)
	
	if not is_valid:
		printerr("Error en el nodo de condición: ", expression.get_error_text())
	
	return is_valid

# Evalúa la condición usando los datos directos de tu motor/MultiMesh
func evaluate(transform: Transform2D, velocity: Vector2 = Vector2.ZERO) -> bool:
	if not is_valid:
		return false
	
	# Preparamos las entradas en el ORDEN exacto de VAR_MAP.values()
	var inputs = [
		transform.origin.x, # pos_x
		transform.origin.y, # pos_y
		velocity.x,         # vel_x
		velocity.y,         # vel_y
		transform.get_rotation() # rot
	]
	
	var result = expression.execute(inputs, null, false)
	return bool(result) if not expression.has_execute_failed() else false
