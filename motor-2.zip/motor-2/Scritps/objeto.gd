extends Control

var Texto = "entida"
var selesiona:bool = true
var Size = Vector2(200,50)
var color_fondo
var primero = StyleBoxFlat.new()
var mode:int = 1
var indice:int = 0

func redondear(prueba):
	var no = prueba
	primero.corner_radius_top_left = no
	primero.corner_radius_top_right = no
	primero.corner_radius_bottom_left = no
	primero.corner_radius_bottom_right = no

func canviar():
	redondear(15)
	primero.bg_color = Color(0.25, 0.25, 0.25, 1.0)
	$Panel.add_theme_stylebox_override("panel", primero)
	$Panel/Button.add_theme_font_size_override("font_size",50)
	$Panel/Button.modulate = Color.WHITE
	$Panel/Button.icon = load("res://sprites/folder.png")

func _ready() -> void:
	if Variables.tipo_entrada == 1:
		$Panel/Button.icon = load("res://sprites/script.png")
		$Panel/Button.text = Texto
		$Panel.size = Size
		$clic.queue_free()
		canviar()
	if Variables.tipo_entrada == 2 and mode==1:
		$Panel/Button.text = Texto
		$clic.queue_free()
		$opp.queue_free()
		if Variables.ide_objeto == $Panel/Button.text:
			presionar(Color(0.2, 0.2, 0.2, 1.0), Color(0.0, 1.0, 0.8, 1.0))

func _input(event):
	if Variables.tipo_entrada == -2 and selesiona:
		selesiona = false
		destroy()
	
	if event is InputEventScreenTouch:
		if mode ==1:
			if Variables.ide_objeto == $Panel/Button.text:
				presionar(Color(0.2, 0.2, 0.2, 1.0), Color(0.0,1.0,0.8,1.0))
			elif Variables.tipo_entrada ==2:
				presionar(Color(0.15,0.15,0.15,1.0), Color(1.0, 1.0, 1.0, 1.0))

func presionar(color1,color2):
	if mode==1:
		redondear(10)
		primero.bg_color = color1
		$Panel.add_theme_stylebox_override("panel", primero)
		$Panel/Button.modulate = color2

func destroy():
	Variables.tipo_entrada = 2
	selesiona = true
	var numero = []
	var posiciones = []
	for a in Variables.objetos_borrar.size():
		var anime = Variables.objetos_borrar[a]
		var no = Variables.referencia2.find(anime)
		numero.append(Variables.cuerpos_fisicos[no])
		posiciones.append(Variables.posiciones[no*2])
		posiciones.append(Variables.posiciones[no*2+1])
		
	for i in Variables.objetos_borrar.size():
		var Name = str(Variables.objetos_borrar[i])
		var Name2 = str(numero[i])
		var Namex = posiciones[i*2]
		var Namey = posiciones[i*2+1]
		#print(Name,Name2,Namex,Namey)
		Variables.referencia2.erase(Name)
		Variables.cuerpos_fisicos.erase(Name2)
		Variables.posiciones.erase(Namex)
		Variables.posiciones.erase(Namey)
	Variables.objetos_borrar.clear()

func ejecuta_el_input():
	Input.action_press("mostrar_componente")
	Input.action_release("mostrar_componente")

func _on_button_pressed() -> void:
	if Variables.tipo_entrada ==2:
		Variables.ide_objeto = $Panel/Button.text
		Variables.ide = Variables.referencia2.find($Panel/Button.text)
		ejecuta_el_input()

func _on_clic_pressed() -> void:
	$Panel/Button.disabled = not $Panel/Button.disabled
	if Variables.ide_objeto == $Panel/Button.text:
		Variables.en_activos[indice] = 0
		Variables.referencia[indice].nodo.hide()
		Variables.ide_objeto = ""
	if $Panel/Button.text == Variables.referencia2[indice] and $clic.button_pressed:
		Variables.ide_objeto = $Panel/Button.text
		Variables.en_activos[indice] = 1
		Variables.referencia[indice].nodo.show()
	ejecuta_el_input()
	
