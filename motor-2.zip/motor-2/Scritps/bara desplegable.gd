extends ColorRect

var lista_palabras:PackedStringArray
var maus:Vector2
var pos:Vector2
var tipo_para_crear:int
var clase_bara:int
var bloquear:bool = false
var dentro:bool = false

@export var name_componente:Array[String]

enum estado{
	PLANTILLAS_ENTIDADES,
	COMPONENTES,
	CONFIGURACION,
	SCENAS,
	LIS_SCRIPT,
}

## crea un entida o componente
signal crear(boton:String,clase:int )
signal configurasion(tipos:String )

func _process(_delta: float) -> void:
	maus = position - get_global_mouse_position()

func _input(event):
	
	if event is InputEventMouseButton:
		pos = event.position
		if bloquear and event.pressed:
			if not si_esta_dentro():
				hide()
				dentro = false
			else:
				dentro = true


func si_esta_dentro():
	var node_rect = Rect2(position, size)
	return node_rect.has_point(pos)

func unir_texto_vertical():
	return "\n".join(Variables.guardar_script[str(Variables.ide)])


func añadir_itens(lis:Array[String]):
	$option.clear()
	for i in range(lis.size()):
		$option.add_item(lis[i],i)


func configura_bara(bar:estado):
	match bar:
		estado.PLANTILLAS_ENTIDADES:
			añadir_itens(["entida basica","cuerpo fisico","area deteccion","add componente"])
			position = Vector2(1001,75)
		estado.COMPONENTES:
			añadir_itens(["cuerpos fisicos","colision","sprite","tipo Button","transform","script visual"])
			position = Vector2(1001,166)
		estado.CONFIGURACION:
			$tex2.text = "salir
			guardar"
			añadir_itens(["salir","guardar"])
			position = Vector2(13,67)
		estado.SCENAS:
			$tex2.text = "nueva ecena"
			position = Vector2(920,67)
			
		estado.LIS_SCRIPT:
			$tex2.text = unir_texto_vertical()
	size = $tex2.size + Vector2(20,23)
	clase_bara = bar
	$option.show_popup()
	show()
	await get_tree().create_timer(0.1).timeout
	bloquear = true


func _on_option_item_selected(index: int) -> void:
	if clase_bara ==2:
		emit_signal("configurasion",name_componente[index])
	elif clase_bara ==0 or clase_bara ==1:
		if clase_bara ==0 and name_componente[index]=="6":
			configura_bara(1 as estado)
		else:
			emit_signal("crear",name_componente[index],clase_bara)
			print(name_componente[index])
			hide()
			dentro = false
			bloquear = false
	
	
	
	
	pass # Replace with function body.
