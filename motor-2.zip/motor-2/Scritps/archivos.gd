extends ColorRect

var array_script = ["jenera entidades.gd","mover randon.gd"]

var con_textos := {}
var con_tipos := {}

var estado:String

func _ready():
	await get_tree().create_timer(0.2).timeout
	for i in $carpetas.nombre_hijos.size():
		var t = $carpetas.nombre_hijos[i]
		con_textos[t] = []
		con_tipos[t] = []
		if t == "texturas":
			for a in Variables.spri_name.size():
				con_textos[t].append(agregar_item_con_salto(Variables.spri_name[a]))
				con_tipos[t].append("textura")
		if t == "scripts":
			for a in array_script.size():
				con_textos[t].append(agregar_item_con_salto(array_script[a]))
				con_tipos[t].append("script")

func agregar_item_con_salto(texto: String):
	var limite_caracteres:int = 10
	var con :int= 10
	var si:int = 0
	var tex :String = ""
	var index:int
	for i in texto:
		si +=1
	if si <= con:
		return texto
	
	
	for i in range(limite_caracteres):
		var h :String= texto[i]
		if h =="m":
			con -=1
		if con != 0:
			tex += h
			index = tex.find(h)
		con -= 1
	var f:String = ""
	var x :int = 0
	for a in texto:
		if x > index:
			f += a
		x += 1
	var cd := tex + "\n" + f
	return cd


func mostrar_contenido():
	var selec = $carpetas.retorna_texto()
	$ites.clear()
	var icon
	for i in range(con_tipos[selec].size()):
		if con_tipos[selec][i] =="textura":
			icon = Variables.sprites[i]
		elif con_tipos[selec][i] == "script":
			icon = load("res://sprites/script.png")
		
		$ites.add_item(con_textos[selec][i], icon)
	$ites.show()
