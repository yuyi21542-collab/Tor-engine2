extends Node2D

var modo := 0#modo de edición renombrar o borrar
var tipo := 0# tipo de material a crear
var mause
var se_puede = true
var maob = "endidad" # diferencia entre crear objeto o un material o añadir una textura 
var boton_estado = "componentes"# indica que es va a crear 
var ruta
@onready var conter_sprite = $ui/selector/lis
@onready var demo = $juego_copia
@onready var nodo = $vara_de_no
@export var lista_de_sprites:Array[Texture2D]
@export var lista_claves:Array[String]= ["icon","logo"]
@export var configurasion:Array
var lista_names:Array[Control] = []
var ruta_escena = "res://juego_2d.tscn"

func _process(_delta: float) -> void:
	mause = get_local_mouse_position()
	var fps = Engine.get_frames_per_second()
	$%FPS.text = "FPS:" + str(int(fps))
	var status = ResourceLoader.load_threaded_get_status(ruta_escena)
	if status == ResourceLoader.THREAD_LOAD_LOADED:
		var escena = ResourceLoader.load_threaded_get(ruta_escena)
		get_tree().change_scene_to_packed(escena)
	$ui/mas_option.position.x = 1160 - $ui/mas_option.size.x
	if Variables.modo_de_edision =="editar" and Variables.limit and Variables.ide_objeto!="":
		demo.mover_punto()
	

func _input(event):
	$vara_de_no.se_puede = se_puede
	if event.is_action_pressed("script")and se_puede:
		nodo.eliminar_nodos_de_lista()
		nodo.eliminar_material()
		maob = "script"
	if Input.is_action_just_pressed("canviar_sprite"):
		$ui/selector.visible = true
		$ui/oculta.visible = true
		$ui/selector/crear_spri.text = "canviar"
	if Input.is_action_just_pressed("abrir_script"):
		maob = "script"
		boton_estado = "script"
		$ui/mas.icon = load("res://sprites/script.png")
		esconder("grupo script",true)
		esconder("grupo editor",false)
		demo.editor.set_show_grid(true)
		demo.eliminar_nodos()
		await get_tree().create_timer(0.05).timeout
		if Variables.block_script[str(Variables.ide)+Variables.editando_el_script].size()>0:
			demo.recargar_nodos()
	if Input.is_action_just_pressed("guardar"):
		$vara_de_no/mensaje.visible = true
		await get_tree().create_timer(0.5).timeout
		$vara_de_no/mensaje.visible = false
	if $ui/bah/opciones.button_pressed:
		$ui/bah/desp.configura_bara(2)
		boton_estado = "opciones"
	if $ui/mas.button_pressed:
		if boton_estado =="script":
			$ui/bah/desp.configura_bara(4)
		else:
			pass
		$ui/bah/desp.configura_bara(3)
	if $ui/salir_al_editor.button_pressed:
		maob = "endidad"
		nodo.get_node("bae").self_modulate = Color.WHITE
		esconder("grupo script",false)
		esconder("grupo editor",true)

func esconder(clase_grupo:String ,se_puede_ver:bool):
	for iten in find_children("","Control",true):
		if iten.is_in_group(clase_grupo):
			if se_puede_ver:
				iten.show()
			else:
				iten.hide()


func _ready() -> void:
	if Variables.tipo_entrada ==1:
		$juego_copia/ui_mover.visible = false
		$vara_de_no.visible = false
	if Variables.tipo_entrada ==2:
		$Camera2D.position = Vector2(320, 50)
		nodo.recargar()
		nodo.conect_categoria_hijos()
		conect_bara_archivos()
	if Variables.tipo_entrada ==2.9:
		$vara_de_no/bae/scrol/VS.set("theme_override_constants/separation",10)
		$juego_copia/ui_mover/visual.set_show_grid(true)
		$juego_copia/ui_mover/visual.visible = true
		$vara_de_no/bae/scrol/VS/eventos.visible = true
		$vara_de_no/bae/scrol/VS/propiedades.visible = true
		demo.recargar_nodos()
	if Variables.sprites.size()< lista_de_sprites.size():
		for i in lista_de_sprites.size():
			Variables.sprites.append(lista_de_sprites[i])
			Variables.spri_name.append(lista_claves[i])
	for i in range(2):
		conter_sprite.add_item(lista_claves[i],Variables.sprites[i])
	
	if configurasion[0] ==0:
		$vara_de_no/bae.position = Vector2(0,13)
		$vara_de_no/bac.position = Vector2(1173,13)
		$vara_de_no/bae.size = Vector2(331,639)
		$vara_de_no/bac.size.y = 707
		$vara_de_no/bac/scrol2.size.y = 600
		$ui/bah/play.position.x = 690
		$ui/bah/debut.position.x = 755
		$ui/bah/opciones.position.x = 340
	else:
		$vara_de_no/bae.position = Vector2(1173,13)
		$vara_de_no/bac.position = Vector2(1173,365)
		$vara_de_no/bae.size = Vector2(381,349)

func conect_bara_archivos():
	for iten in $vara_de_no/vara2/h.get_children():
		iten.pressed.connect(abro_la_vara_de_archivos.bind(iten.name))

func dime_para_crear_el_com(normal:int): #deside que es lo que se crear
	if normal != 5:
		if Variables.numero_componestes > Variables.cuenta[Variables.ide]:
			nodo.mostrar_ecena(normal,true,"","crear",0)
		else:
			nodo.mostrar_escena_rapido(normal,true,"",0)
	else:
		Input.action_press("mas_script")
		Input.action_release("mas_script")
	se_puede = true

func abro_la_vara_de_archivos(tip):
	var ob = "vara_de_no/vara2/h/"
	if $vara_de_no/vara2.position.y == 660:
		$vara_de_no/vara2.position.y = 420
		get_node(ob+tip).modulate = Color(0.0, 1.0, 0.95, 1.0)
	else:
		get_node(ob+tip).modulate = Color(1.0, 1.0, 1.0, 1.0)
		$vara_de_no/vara2.position.y = 660

func salir_al_editor():
	get_tree().call_deferred("change_scene_to_file", "res://editor.tscn")

func _on_play_pressed() -> void:
	Variables.modo_de_edision = "jugar"
	if Variables.guardar_script.has(str(Variables.ide)):
		Input.action_press("guardar")
		Input.action_release("guardar")
	$ui/oculta.show()
	$ui/oculta/logo.show()
	$ui/oculta.modulate = Color.WHITE
	ResourceLoader.load_threaded_request(ruta_escena)
	#get_tree().call_deferred("change_scene_to_file", "res://juego_2d.tscn")

func _on_button_pressed() -> void:
	$ui/selector.visible = false
	$ui/oculta.visible = false
	Variables.sprite_a_canviar = -1

func _on_crear_spri_pressed() -> void:
	$ui/selector.visible = false
	$ui/oculta.visible = false
	if $ui/selector.titulo != "sprite":
		$ui/selector.normalisa_valores()
		Input.action_press("asigna una textura")
		Input.action_release("asigna una textura")
		return
	
	var ruta_enti:Sprite = Variables.optener_componente("Sprite")
	if $ui/selector/crear_spri.text =="canviar":
		var clave = int(Variables.sprite_a_canviar)
		ruta_enti.textura = Variables.sprites[clave].resource_path
	Input.action_press("asigna una textura")
	Input.action_release("asigna una textura")
	
	if maob == "script":
		for i in demo.refe_nodos.size():
			if demo.refe_nodos[i].name == Variables.sprite_name:
				demo.refe_nodos[i].valor = Variables.sprite_a_canviar
				var promo = demo.refe_nodos[i].get_node("x/sprite")
				promo.texture_normal = Variables.sprites[Variables.sprite_a_canviar]
				var text_size = promo.texture_normal.get_size()
				promo.scale.x = 90 / text_size.x
				promo.scale.y = 90 / text_size.y
	await get_tree().create_timer(0.1).timeout
	Variables.sprite_a_canviar = -1


func _on_lis_item_selected(index: int) -> void:
	Variables.sprite_a_canviar = index

func _on_desp_configurasion(tipos: String) -> void:
	if tipos =="3":
		salir_al_editor()
	if tipos =="4":
		Input.action_press("guardar")
		Input.action_release("guardar")

func _on_entidades_canviar_estado_vara(tex: String, nu: int) -> void:
	$ui/bah/desp.configura_bara(nu)
	boton_estado = tex

func _on_conten_datos_abrir_editor_recuadro() -> void:
	#$ui/selector/Button
	$ui/selector/lis.hide()
	$ui/selector.show()
	
	
	pass # Replace with function body.
