extends Node2D

var refe = load("res://objeto.tscn")
var ruta_escena = "res://ventana.tscn"
var caga = load("res://ventana.tscn")
var progreso = []
var pro
var selesiona = "proyecto"
var Version = "ALFA 8"
var estilo = StyleBoxFlat.new()
var estilo2 = StyleBoxFlat.new()

func _input(event):
	if event is InputEventScreenTouch:
		if $ui/e/p.button_pressed:
			selesiona = str($ui/e/p.name)
		if $ui/dd/d.button_pressed:
			selesiona = str($ui/dd/d.name)
		coloreal_botones()

func coloreal_botones():
	if selesiona =="p":
		estilo.bg_color = Color(0.0, 0.78, 0.741, 1.0)
		$ui/e.add_theme_stylebox_override("panel",estilo)
	else:
		estilo.bg_color = Color(0.13, 0.13, 0.13, 1.0)
		$ui/e.add_theme_stylebox_override("panel",estilo)
	if selesiona =="d":
		estilo2.bg_color = Color(0.0, 0.78, 0.741, 1.0)
		$ui/dd.add_theme_stylebox_override("panel",estilo2)
	else:
		estilo2.bg_color = Color(0.13, 0.13, 0.13, 1.0)
		$ui/dd.add_theme_stylebox_override("panel",estilo2)
	redondear_botones()

func redondear_botones():
	var no = 10
	estilo.corner_radius_top_left = no
	estilo.corner_radius_top_right = no
	estilo.corner_radius_bottom_left = no
	estilo.corner_radius_bottom_right = no
	
	estilo2.corner_radius_top_left = no
	estilo2.corner_radius_top_right = no
	estilo2.corner_radius_bottom_left = no
	estilo2.corner_radius_bottom_right = no


func _ready():
	$can/version.text = Version
	_preparar_escena()
	Variables.tipo_entrada = 1
	pro = refe.instantiate()
	var boton = pro.get_node("Panel/Button")
	var oop = pro.get_node("Panel/puntos")
	boton.size = Vector2(600,130)
	boton.set("theme_override_constants/icon_max_width",70)
	pro.Texto = "Proyecto"
	pro.Size = Vector2(600,130)
	oop.position = Vector2(530,45)
	oop.scale = Vector2(0.7,0.7)
	pro.color_fondo = Color(1.0, 1.0, 1.0, 1.0)
	$can/s/lista.add_child(pro)
	task_id = WorkerThreadPool.add_task(_preparar_escena)
	await get_tree().create_timer(0.5).timeout
	
	mostrar_escena_rapido()
	#$pre.queue_free()

var insta_componente: Node2D = null
var task_id: int = -1

func _preparar_escena() -> void:
	ResourceLoader.load_threaded_request(ruta_escena)
	while ResourceLoader.load_threaded_get_status(ruta_escena) == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
		OS.delay_msec(3) # Espera un milisegundo si aún no termina
	var packed_scene = ResourceLoader.load_threaded_get(ruta_escena)
	if packed_scene:
		insta_componente = packed_scene.instantiate()

func mostrar_escena_rapido() -> void:
	if WorkerThreadPool.is_task_completed(task_id) and insta_componente:
		add_child.call_deferred(insta_componente)
		insta_componente.name = "p"
		await get_tree().create_timer(0.5).timeout
		$p.queue_free()
		insta_componente = null
	else:
		print("La escena aún se está procesando en segundo plano...")


func cargar_escena():
	ResourceLoader.load_threaded_request(ruta_escena)

func _process(_delta):
	var status = ResourceLoader.load_threaded_get_status(ruta_escena)
	if status == ResourceLoader.THREAD_LOAD_LOADED:
		var escena = ResourceLoader.load_threaded_get(ruta_escena)
		get_tree().change_scene_to_packed(escena)

func _on_objetos_pressed() -> void:
	$ui/carga.visible = true
	Variables.tipo_entrada = 2
	await get_tree().create_timer(0.02).timeout
	cargar_escena()
