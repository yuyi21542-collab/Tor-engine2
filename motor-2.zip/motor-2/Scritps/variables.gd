extends Node

var color:Color = Color.WHITE
var tipo_entrada = 2
var objetos_borrar:= []
var referencia := []

##contiene todos los nombres de las entidades en la esena
var referencia2:PackedStringArray = []#nombres reales

var inicial := {}#esto es para los valores iniciales
var en_activos:PackedInt32Array = []#entidades activas

var referencia3 := []#sprites asignados
var claves_de_propiedades := []
var lista_de_iten:Array

#usado para canviar propiedades
var modo_de_edision := "editar"# "no_as_nada"
var sprite_name := ""
var sprite_a_canviar:int = -1
var limit:bool = true 

#para los nodos de codigo
var nodos_posiciones :={}
var scrit_nodos := {}
var block_script = {}
var block_script_global: = {}#X
var script_globales: = {}#X
var conexiones: = {}

#nueva forma optimizada para guardar las claves y valores
var index_comenzar:PackedInt32Array
var index_por_siempre:PackedInt32Array
var index_input:PackedInt32Array
var claves_para_script:PackedInt32Array
var valores_para_script:Array
#ejecuta y guarda los script
var guardar_script = {}
var editando_el_script: = "script1"

#para diferenciar nodos
var contador := {}
var lis_requisitos:= [] #esto es para pasar los balores del editor a los nodos

#para diferenciar las entidades
var ide_objeto:String = ""
var ide:int = 0

var disionarios_objetos := {}

#contiene los recursos
var materiales := {}
var sprites:Array[Texture2D] = []
var spri_name:PackedStringArray

func optener_componente(clase:String):
	
	for i in inicial[str(ide)]:
		if i.nombre_componentes ==clase:
			return i
	return false
