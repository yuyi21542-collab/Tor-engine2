extends Panel

var titulo: = "region"
var maus:Vector2i
var vec: = Vector2i(256,256)

func _ready():
	$rec/x.gui_input.connect(gui_input_x)
	$rec/y.gui_input.connect(gui_input_y)
	$x.text_changed.connect(actualizar_textos)
	$y.text_changed.connect(actualizar_textos)
	$an.text_changed.connect(actualizar_textos)
	$al.text_changed.connect(actualizar_textos)
	actualizar_valores()
	

func _input(event):
	if event is InputEventKey:return
	maus = event.position - position
	
	if titulo =="sprite":
		if Variables.sprite_a_canviar != -1:
			$crear_spri.disabled = false
		else:
			$crear_spri.disabled = true
	

func _process(_delta):
	$rec/y.position = $rec.size-Vector2(12,12)
	var c = $rec.position -Vector2(125,102)
	vec = c + $rec/y.position+Vector2(12,12)

func normalisa_valores():
	var ma = 128
	var r:=Vector2(float($an.text)/ma,float($al.text)/ma)
	var p:=Vector2(float($x.text)/ma,float($y.text)/ma)# + r/2
	Variables.optener_componente("Sprite").region = Rect2(p, r)

func actualizar_textos(_tex:String):
	$rec.position.x = int($x.text)*2 +125
	$rec.position.y = int($y.text)*2 +102 
	$rec.size.x = int($an.text)*2
	$rec.size.y = int($al.text)*2


func actualizar_valores():
	$an.text = str($rec.size.x/2)
	$al.text = str($rec.size.y/2)
	
	var po =$rec.position-Vector2(125,102)
	
	$x.text = str(po.x/2)
	$y.text = str(po.y/2)

func gui_input_x(event):
	if event is InputEventScreenDrag:
		$rec.position = maus
		$rec.size = vec - maus+ Vector2i(125,102)
		actualizar_valores()

func gui_input_y(event):
	if event is InputEventScreenDrag:
		$rec.size = maus - Vector2i($rec.position)
		actualizar_valores()
