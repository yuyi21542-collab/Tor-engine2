extends Node2D

@export var min_zoom: float = 0.5
@export var max_zoom: float = 3.0
@export var zoom_speed: float = 0.1
@export var drag_speed: float = 1.0

var camara: Camera2D
var is_dragging := false
var drag_start_position = Vector2.ZERO
var camera_start_position = Vector2.ZERO

var touch_1_index = -1
var touch_2_index = -1
var touch_1_position = Vector2.ZERO
var touch_2_position = Vector2.ZERO
var last_pinch_distance = 0.0
var is_pinching = false

var viupor:Vector2 = Vector2(1172,655)

func _ready():
	camara = get_viewport().get_camera_2d()
	if not camara:
		camara = Camera2D.new()
		add_child(camara)
		camara.make_current()

func esta_dentro(event) -> bool:
	if event is InputEventKey:
		return false
	
	if event.position.x <viupor.x and event.position.y <viupor.y:
		return true
	else:
		return false


func _input(event: InputEvent) -> void:
	var co := esta_dentro(event)
	if event is InputEventScreenTouch and Variables.modo_de_edision=="editar" and co:
		if event.pressed:
			if touch_1_index == -1:
				touch_1_index = event.index
				touch_1_position = event.position
				is_dragging = true
				drag_start_position = event.position
				camera_start_position = global_position
			elif touch_2_index == -1:
				touch_2_index = event.index
				touch_2_position = event.position
				is_pinching = true
				last_pinch_distance = touch_1_position.distance_to(touch_2_position)
				is_dragging = false
		else:
			if event.index == touch_1_index:
				touch_1_index = -1
				if touch_2_index != -1:
					touch_1_index = touch_2_index
					touch_1_position = touch_2_position
					touch_2_index = -1
					is_dragging = true
					drag_start_position = touch_1_position
					camera_start_position = camara.global_position
				else:
					is_dragging = false
				is_pinching = false
			elif event.index == touch_2_index:
				touch_2_index = -1
				is_pinching = false
				is_dragging = true
				drag_start_position = touch_1_position
				camera_start_position = global_position

	if event is InputEventScreenDrag and Variables.modo_de_edision=="editar" and co:
		if event.index == touch_1_index:
			touch_1_position = event.position
		elif event.index == touch_2_index:
			touch_2_position = event.position
		if is_pinching and touch_1_index != -1 and touch_2_index != -1:
			var current_disntance = touch_1_position.distance_to(touch_2_position)
			if last_pinch_distance > 0:
				var distance_delta = current_disntance - last_pinch_distance
				var zoom_factor = 1.0 + (distance_delta * zoom_speed * 0.01)
				var new_zoom = camara.zoom * zoom_factor
				new_zoom = new_zoom.clamp(Vector2(min_zoom, min_zoom), Vector2(max_zoom, max_zoom))
				camara.zoom = new_zoom
			last_pinch_distance = current_disntance
		if is_dragging and event.index == touch_1_index:
			var drag_vector = (drag_start_position - event.position) * drag_speed / camara.zoom.x
			global_position = camera_start_position + drag_vector
	
