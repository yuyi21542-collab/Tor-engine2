extends Node

var tree_esta_editando: bool = false
var estado_teclado:= false

signal teclado_ocultodo

func esta_el_teclado_activo() -> bool:
	if DisplayServer.virtual_keyboard_get_height() > 0:
		return true
	
	# 3. Caso Teclado Flotante en otras cajas de texto de la UI
	var nodo_enfocado = get_tree().root.gui_get_focus_owner()
	if nodo_enfocado:
		# Si está enfocado en cajas de texto normales de la UI
		if nodo_enfocado is LineEdit or nodo_enfocado is TextEdit:
			
			return true
		
		if nodo_enfocado.get_parent() is CarpetasDesplegable or nodo_enfocado.get_class() == "TreeTextEditor":
			return true
	return false


func _process(_delta):
	if esta_el_teclado_activo() and not estado_teclado:
		estado_teclado = true
	if not esta_el_teclado_activo() and estado_teclado:
		estado_teclado = false
		teclado_ocultodo.emit()
