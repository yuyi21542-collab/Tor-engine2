extends GraphNode

var mode
@export_enum(
	"comenzar",
	"por siempre",
	"cuando toque",
	"texture",
	"modulate",
	"position",
	"rotation",
	"velocity",
	"si es verdadero",
	) var lis_mode:String
var componente = "cuerpo"
var valor = "100.0"
var valor2 = "0"
var propiedad
var maus
var borrar:bool = false
var primero = StyleBoxFlat.new()
var lista_nodos:Array[Node]

@onready var elimina = $borrar


func redondear(prueba:int, evento:bool, input:bool):
	var no = prueba
	primero.corner_radius_top_left = no
	primero.corner_radius_top_right = no
	primero.corner_radius_bottom_right = no
	primero.corner_radius_bottom_left = no
	primero.border_width_top = 7
	primero.content_margin_top = 20
	if evento:
		if input ==false:
			$x/lab.modulate.a = 0
		set("slot/0/left_enabled",false)
		primero.bg_color = Color(0.54, 0.0, 0.0, 1.0)
	primero.border_color = primero.bg_color
	add_theme_stylebox_override("titlebar", primero)

func linpiar_con_nombres(lista:Array):
	var con = 0
	for nodo in lista_nodos:
		if nodo.name == lista[con]:
			$x.get_node(lista[con]).show()
			if lista.size()-1 != con:
				con +=1
		else:
			nodo.hide()

func _ready() -> void:
	set_process(false)
	lista_nodos = $x.get_children()
	if mode ==null:
		mode = lis_mode
	configura_nodo()


func configura_nodo():
	#linpiar_con_nombres([""])
	size.y = 80
	if mode == "comenzar" or mode=="por siempre":
		redondear(10,true,false)
	elif mode =="cuando toque":
		redondear(10,true,true)
	elif mode !="cuando toque":
		redondear(10,false,false)
	
	match mode:
		"comenzar":
			$c/titu.text = "comenzar"
		"por siempre":
			$c/titu.text = "por siempre"
		"cuando toque":
			linpiar_con_nombres(["lab","obtienes"])
			size = Vector2(175,110)
			elimina.position.x = 148
			$c/titu.text = "toque pantalla"
			$x/lab.text = "en la"
		
		
		"texture":
			$c/titu.text = "textura"
			$x/lab.text = "nueva textura"
			componente = "sprite"
			linpiar_con_nombres(["lab","sprite"])
			valor = "logo"
			size = Vector2(160,160)
			primero.bg_color = Color(0.19, 0.57, 0.0, 1.0)
		"modulate":
			$c/titu.text = "color"
			$x/lab.text = "nuevo color"
			linpiar_con_nombres(["lab","color"])
			valor = $x/color.color
			size.y = 100
			primero.bg_color = Color(0.0, 0.527, 0.398, 1.0)
		"position":
			$c/titu.text = "posicion"
			$x/lab.text = "en X"
			$x/la.text = "en Y"
			linpiar_con_nombres(["lab","tex","la","tex2"])
			primero.bg_color = Color(0.091, 0.256, 0.61, 1.0)
			size = Vector2(160,110)
		"rotation":
			set_process(true)
			$c/titu.text = "rotacion"
			linpiar_con_nombres(["lab","tex"])
			$c/rotar.visible = true
			size = Vector2(160,150)
			$x/lab.text = "nueva diresion"
			primero.bg_color = Color(0.283, 0.0, 1.0, 1.0)
		"velocity":
			$c/titu.text = "velosidad"
			$x/lab.text = "en X"
			$x/la.text = "en Y"
			linpiar_con_nombres(["lab","tex","la","tex2"])
			size.y = 110
			primero.bg_color = Color(0.0, 0.741, 0.573, 1.0)
		"si es verdadero":
			$c/titu.text = "si es verdadero"
			$x/lab.text = "condision"
			$s.visible = true
			elimina.position.x = 157
			if valor =="100.0":
				valor = "1>2"
			$x/tex.text = valor
			linpiar_con_nombres(["lab","tex"])
			size = Vector2(184,100)
			set("slot/0/right_color",Color(0.17, 0.239, 1.0, 1.0))
			primero.bg_color = Color(0.8, 0.368, 0.136, 1.0)
	primero.border_color = primero.bg_color
	
	await get_tree().create_timer(0.1).timeout
	if Variables.block_script.has(str(Variables.ide) +Variables.editando_el_script):
		if Variables.block_script[str(Variables.ide)+Variables.editando_el_script].size()>1:
			asignar_prod()

func asignar_prod():
	match mode:
		"texture":
			$x/sprite.texture_normal = Variables.sprites[valor]
			var text_size = $x/sprite.texture_normal.get_size()
			$x/sprite.scale.x = 90 / text_size.x
			$x/sprite.scale.y = 90 / text_size.y
		"modulate":
			$x/color.color = valor
		"position":
			$x/tex.text = str(valor.x)
			$x/tex2.text = str(valor.y)
		"rotation":
			$x/tex.text = str(valor)
			$c/rotar.rotation_degrees = valor
		"velocity":
			$x/tex.text = str(valor.x)
			$x/tex2.text = str(valor.y)
		"si es verdadero":
			$x/tex.text = valor
		

func _input(_event):
	if Input.is_action_just_pressed("guardar"):
		guardar()

func guardar():
	match $c/titu.text:
		"color":
			valor = $x/color.color
		"posicion":
			valor = Vector2(int($x/tex.text),int($x/tex2.text))
		"rotacion":
			valor = $c/rotar.rotation_degrees
		"velosidad":
			valor = Vector2(int($x/tex.text),int($x/tex2.text))
		"si es verdadero":
			valor = $x/tex.text

func _on_sprite_pressed() -> void:
	Variables.sprite_name = str(name)

func _on_tex_pressed() -> void:
	guardar_requisitos("primero")

func _on_tex_2_pressed() -> void:
	guardar_requisitos("segundo")

func guardar_requisitos(nombre):
	guardar()
	Input.action_press("guardar")
	Input.action_release("guardar")
	Variables.lis_requisitos.clear()
	Variables.lis_requisitos.append(componente)
	Variables.lis_requisitos.append(mode)
	Variables.lis_requisitos.append(name)
	Variables.lis_requisitos.append(valor)
	Variables.lis_requisitos.append(nombre)
	get_tree().call_deferred("change_scene_to_file", "res://Escenas/editor_de_codigo.tscn")

func _on_borrar_pressed() -> void:
	borrar = true
