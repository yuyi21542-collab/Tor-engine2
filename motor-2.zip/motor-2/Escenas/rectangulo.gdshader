shader_type canvas_item;

uniform vec2 recuadro_centro = vec2(0.5, 0.5); // Centro del recuadro (de 0 a 1)
uniform vec2 recuadro_tamano = vec2(0.2, 0.2); // Ancho y alto del recuadro (de 0 a 1)
uniform float brillo_oscuro : hint_range(0.0, 1.0) = 0.8; // Brillo fuera del recuadro
uniform float suavizado : hint_range(0.0, 0.1) = 0.01; // Suavizado de los bordes del recuadro

void fragment() {
    // 1. Obtenemos el color original de la textura
    vec4 color_original = texture(TEXTURE, UV);
    
    // 2. Calculamos los límites del recuadro (Izquierda, Derecha, Abajo, Arriba)
    vec2 limite_min = recuadro_centro - (recuadro_tamano * 0.5);
    vec2 limite_max = recuadro_centro + (recuadro_tamano * 0.5);
    
    // 3. Verificamos si el pixel actual (UV) está dentro del recuadro usando un paso suave
    vec2 dentro_x = smoothstep(limite_min, limite_min + suavizado, UV) * (1.0 - smoothstep(limite_max - suavizado, limite_max, UV));
    //vec2 dentro_y = smoothstep(limite_min, limite_min + suavizado, UV) * (1.0 - smoothstep(limite_max - suavizado, limite_max, UV));
    
    // Multiplicamos X e Y para saber si está totalmente dentro de ambos ejes
    float mascara_recuadro = dentro_x.x * dentro_x.y;
    
    // 4. Creamos la versión oscura de la textura
    vec4 color_oscuro = vec4(color_original.rgb * brillo_oscuro, color_original.a);
    
    // 5. Mezclamos el color oscuro y el normal basándonos en la máscara del recuadro
    COLOR = mix(color_oscuro, color_original, mascara_recuadro);
}
